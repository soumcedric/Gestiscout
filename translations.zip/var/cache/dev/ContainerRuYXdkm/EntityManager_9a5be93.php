<?php

namespace ContainerRuYXdkm;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{

    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder20afe = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializer085b7 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties4f742 = [
        
    ];

    public function getConnection()
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'getConnection', array(), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'getMetadataFactory', array(), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'getExpressionBuilder', array(), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'beginTransaction', array(), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->beginTransaction();
    }

    public function getCache()
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'getCache', array(), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->getCache();
    }

    public function transactional($func)
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'transactional', array('func' => $func), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->transactional($func);
    }

    public function commit()
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'commit', array(), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->commit();
    }

    public function rollback()
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'rollback', array(), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'getClassMetadata', array('className' => $className), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'createQuery', array('dql' => $dql), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'createNamedQuery', array('name' => $name), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'createQueryBuilder', array(), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'flush', array('entity' => $entity), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'clear', array('entityName' => $entityName), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->clear($entityName);
    }

    public function close()
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'close', array(), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->close();
    }

    public function persist($entity)
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'persist', array('entity' => $entity), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'remove', array('entity' => $entity), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'refresh', array('entity' => $entity), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'detach', array('entity' => $entity), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'merge', array('entity' => $entity), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'getRepository', array('entityName' => $entityName), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'contains', array('entity' => $entity), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'getEventManager', array(), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'getConfiguration', array(), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'isOpen', array(), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'getUnitOfWork', array(), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'getProxyFactory', array(), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'initializeObject', array('obj' => $obj), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'getFilters', array(), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'isFiltersStateClean', array(), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'hasFilters', array(), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return $this->valueHolder20afe->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializer085b7 = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder20afe) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder20afe = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder20afe->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, '__get', ['name' => $name], $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        if (isset(self::$publicProperties4f742[$name])) {
            return $this->valueHolder20afe->$name;
        }

        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder20afe;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    get_parent_class($this),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
            return;
        }

        $targetObject = $this->valueHolder20afe;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, '__set', array('name' => $name, 'value' => $value), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder20afe;

            $targetObject->$name = $value; return $targetObject->$name;
            return;
        }

        $targetObject = $this->valueHolder20afe;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value; return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, '__isset', array('name' => $name), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder20afe;

            return isset($targetObject->$name);
            return;
        }

        $targetObject = $this->valueHolder20afe;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, '__unset', array('name' => $name), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder20afe;

            unset($targetObject->$name);
            return;
        }

        $targetObject = $this->valueHolder20afe;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __clone()
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, '__clone', array(), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        $this->valueHolder20afe = clone $this->valueHolder20afe;
    }

    public function __sleep()
    {
        $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, '__sleep', array(), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;

        return array('valueHolder20afe');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializer085b7 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializer085b7;
    }

    public function initializeProxy() : bool
    {
        return $this->initializer085b7 && ($this->initializer085b7->__invoke($valueHolder20afe, $this, 'initializeProxy', array(), $this->initializer085b7) || 1) && $this->valueHolder20afe = $valueHolder20afe;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder20afe;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder20afe;
    }


}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}

<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* base.html.twig */
class __TwigTemplate_8b49e5ae53aa6ee245d8c75197fe672aee85b1300d3a62873833c0b2f42f89d3 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'titre' => [$this, 'block_titre'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\">
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        <link rel=\"icon\" href=\"favicon.ico\" type=\"image/x-icon\">
<!-- VENDOR CSS -->
        <!-- VENDOR CSS -->
        <link rel=\"stylesheet\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/bootstrap/css/bootstrap.min.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/font-awesome/css/font-awesome.min.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/animate-css/vivify.min.css"), "html", null, true);
        echo "\">

        <link rel=\"stylesheet\" href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/c3/c3.min.css"), "html", null, true);
        echo "\"/>
        <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/chartist/css/chartist.min.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/chartist-plugin-tooltip/chartist-plugin-tooltip.css"), "html", null, true);
        echo "\">
";
        // line 17
        echo "

        <!-- MAIN CSS -->
        <link rel=\"stylesheet\" href=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("site.min.css"), "html", null, true);
        echo "\">


        ";
        // line 23
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 30
        echo "    </head>
    <body class=\"theme-blue\">
        <!-- Page Loader -->
";
        // line 39
        echo "
<!-- Overlay For Sidebars -->
<div class=\"overlay\"></div>
<div id=\"wrapper\">

    <nav class=\"navbar navbar-fixed-top\">
        <div class=\"container-fluid\">

            <div class=\"navbar-left\">
                <div class=\"navbar-brand\">
                    <a class=\"small_menu_btn\" href=\"javascript:void(0);\"><i class=\"fa fa-align-left\"></i></a>
                    <a href=\"";
        // line 50
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("Dashboard");
        echo "\"><span>GestiScout</span></a>
                </div>
                <form id=\"navbar-search\" class=\"navbar-form search-form\">
";
        // line 55
        echo "
                </form>
            </div>
            <h3 class=\"text-white\"><strong>";
        // line 58
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 58, $this->source); })()), "user", [], "any", false, false, false, 58), "Groupe", [], "any", false, false, false, 58), "getNom", [], "any", false, false, false, 58), "html", null, true);
        echo "</strong></h3>
            <div class=\"navbar-right\">
                <div id=\"navbar-menu\">

                    <ul class=\"nav navbar-nav\">
";
        // line 171
        echo "                        <li><a href=\"";
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_logout");
        echo "\" class=\"icon-menu\"><i class=\"fa fa-power-off\"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>
    <div id=\"rightbar\" class=\"rightbar\">
        <div class=\"slim_scroll\">
            <div class=\"chat_detail vivify fadeIn delay-100\">
                <ul class=\"chat-widget clearfix\">
                    <li class=\"left float-left\">
                        <div class=\"avtar-pic w35 bg-pink\"><span>KG</span></div>
                        <div class=\"chat-info\">
                            <span class=\"message\">Hello, John<br>What is the update on Project X?</span>
                        </div>
                    </li>
                    <li class=\"right\">
                        <img src=\"../assets/images/xs/avatar1.jpg\" class=\"rounded\" alt=\"\">
                        <div class=\"chat-info\">
                            <span class=\"message\">Hi, Alizee<br> It is almost completed. I will send you an email later today.</span>
                        </div>
                    </li>
                    <li class=\"left float-left\">
                        <div class=\"avtar-pic w35 bg-pink\"><span>KG</span></div>
                        <div class=\"chat-info\">
                            <span class=\"message\">That's great. Will catch you in evening.</span>
                        </div>
                    </li>
                    <li class=\"right\">
                        <img src=\"../assets/images/xs/avatar1.jpg\" class=\"rounded\" alt=\"\">
                        <div class=\"chat-info\">
                            <span class=\"message\">Sure we'will have a blast today.</span>
                        </div>
                    </li>
                </ul>
                <div class=\"input-group p-t-15\">
                    <textarea rows=\"3\" class=\"form-control\" placeholder=\"Enter text here...\"></textarea>
                </div>
            </div>
        </div>
    </div>
    <div id=\"left-sidebar\" class=\"sidebar\">

        <div class=\"sidebar_icon\">
            <ul class=\"nav nav-tabs\">
";
        // line 217
        echo "                <li class=\"nav-item\"><a class=\"nav-link active\" data-toggle=\"tab\" href=\"#Home-icon\"><i class=\"fa fa-dashboard\"></i></a></li>
";
        // line 220
        echo "                <li class=\"nav-item\">
                    <a class=\"nav-link\" data-toggle=\"tab\" href=\"#Profile-icon\"><i class=\"fa fa-user\"></i></a>
";
        // line 223
        echo "                </li>
            </ul>
        </div>
        <div class=\"sidebar_list\">
            <div class=\"tab-content\" id=\"main-menu\">
                <div class=\"tab-pane active\" id=\"Home-icon\">
                    <nav class=\"sidebar-nav sidebar-scroll\">
                        <ul class=\"metismenu\">
                            <li class=><img src=\"";
        // line 231
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("/img_logo/LOGO.jpg"), "html", null, true);
        echo "\" class=\"img-fluid\" WIDTH=\"170\" height=\"150\"></li>
                            <li class=\"active\"><a href=\"";
        // line 232
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("Dashboard");
        echo "\"><i class=\"fa fa-dashboard\"></i><span>Dashboard</span></a></li>


                            ";
        // line 235
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_SUPERADMIN")) {
            // line 236
            echo "                            <li class=\"header\">Configuration</li>
                            <li><a href=\"";
            // line 237
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("ListeAnnePastorale");
            echo "\"><i class=\"fa fa-wrench\"></i><span>Année pastorale</span></a></li>
                            <li><a href=\"";
            // line 238
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("ListeBranche");
            echo "\"><i class=\"fa fa-wrench\"></i><span>Branche</span></a></li>
                            <li><a href=\"";
            // line 239
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("ListeFonction");
            echo "\"><i class=\"fa fa-wrench\"></i><span>Fonction</span></a></li>
                                <li><a href=\"";
            // line 240
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("Groupe");
            echo "\"><i class=\"fa fa-wrench\"></i><span>Groupe</span></a></li>
                            ";
        }
        // line 242
        echo "

                            ";
        // line 244
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_CG")) {
            // line 245
            echo "                            <li class=\"header\">Jeunes</li>
                            <li><a href=\"";
            // line 246
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AddJeune");
            echo "\"><i class=\"fa fa-plus\"></i><span>Nouveau jeune</span></a></li>
                            <li><a href=\"";
            // line 247
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("ListeJeunes");
            echo "\"><i class=\"fa fa-list\"></i><span>Liste des jeunes</span></a></li>
                             <li class=\"header\">Responsable</li>
                            <li><a href=\"";
            // line 249
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AjouterRespoView");
            echo "\"><i class=\"fa fa-plus\"></i><span>Nouveau responsable</span></a></li>
                            <li><a href=\"";
            // line 250
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("responsable");
            echo "\"><i class=\"fa fa-list\"></i><span>Liste des responsables</span></a></li>
                            ";
        }
        // line 252
        echo "

                        ";
        // line 254
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_ADMIN")) {
            // line 255
            echo "
                            <li class=\"header\">Responsable</li>
                            <li><a href=\"";
            // line 257
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AjouterRespoView");
            echo "\"><i class=\"fa fa-plus\"></i><span>Nouveau responsable</span></a></li>
                            <li><a href=\"";
            // line 258
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("responsable");
            echo "\"><i class=\"fa fa-list\"></i><span>Liste des responsables</span></a></li>
                        ";
        }
        // line 260
        echo "



                            ";
        // line 264
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_CG")) {
            // line 265
            echo "                                <li class=\"header\">Cotisation</li>
";
            // line 268
            echo "
                                <li>
                                <a href=\"#Tables\" class=\"has-arrow\"><i class=\"fa fa-plus-circle\"></i><span>Cotisation Jeune</span></a>
                                <ul>
                                    <li><a href=\"";
            // line 272
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("cotisation");
            echo "\">Faire une cotisation</a></li>
                                    <li><a href=\"";
            // line 273
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("ViewJeuneCotise");
            echo "\">Liste des cotisés</a></li>

                                </ul>
                                </li>
                                <li>
                                    <a href=\"#Tables1\" class=\"has-arrow\"><i class=\"fa fa-plus-circle\"></i><span>Cotisation Chef</span></a>
                                    <ul>
                                        <li><a href=\"";
            // line 280
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("cotisationResponsable");
            echo "\">Faire une cotisation</a></li>
                                        <li><a href=\"";
            // line 281
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("ViewResponsableCotise");
            echo "\">Liste des cotisés</a></li>
                                    </ul>
                                </li>





";
            // line 295
            echo "

                            ";
        }
        // line 298
        echo "

                            ";
        // line 300
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_CONSULTANT")) {
            // line 301
            echo "                                <li class=\"header\">Jeunes</li>
                                <li><a href=\"";
            // line 302
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("ListeJeunes");
            echo "\"><i class=\"fa fa-list\"></i><span>Liste des jeunes</span></a></li>
                                <li><a href=\"";
            // line 303
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("ViewJeuneCotise");
            echo "\"><i class=\"fa fa-list\"></i><span>Liste des cotisés</span></a></li>

                            ";
        }
        // line 306
        echo "






                        </ul>
                    </nav>
                </div>
                <div class=\"tab-pane\" id=\"Profile-icon\">
                    <nav class=\"sidebar-nav sidebar-scroll\">
                        <div class=\"user-detail\">
                            <div class=\"text-center mb-3\">
                                <img class=\"img-thumbnail rounded-circle\" src=\"../assets/images/sm/avatar1.jpg\" alt=\"\">
                                <h6 class=\"mt-3 mb-0\">";
        // line 321
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 321, $this->source); })()), "user", [], "any", false, false, false, 321), "responsable", [], "any", false, false, false, 321), "getNom", [], "any", false, false, false, 321), "html", null, true);
        echo "</h6>
                                <div class=\"text-center text-muted\">";
        // line 322
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 322, $this->source); })()), "user", [], "any", false, false, false, 322), "responsable", [], "any", false, false, false, 322), "getPrenoms", [], "any", false, false, false, 322), "html", null, true);
        echo "</div>
                                <hr>
";
        // line 332
        echo "                            </div>
                            <hr>
                            <div class=\"card-text\">
                                <div class=\"mt-0\">
";
        // line 341
        echo "                                </div>
                                <div class=\"mt-4\">
";
        // line 348
        echo "                                </div>
                                <div class=\"mt-4\">
";
        // line 355
        echo "                                </div>
                                <div class=\"mt-4\">
";
        // line 362
        echo "                                </div>
                            </div>
                        </div>
                    </nav>
                </div>

            </div>
        </div>
    </div>
    <div id=\"main-content\">
        ";
        // line 372
        $this->displayBlock('body', $context, $blocks);
        // line 373
        echo "
    </div>
</div>





            <script src=\"";
        // line 381
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/jquery/jquery-3.3.1.min.js"), "html", null, true);
        echo "\"></script>


            <script src=\"";
        // line 384
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/bootstrap/js/bootstrap.bundle.min.js"), "html", null, true);
        echo "\"></script>

            <script src=\"";
        // line 386
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("bundles/vendorscripts.bundle.js"), "html", null, true);
        echo "\"></script>

            <script src=\"";
        // line 388
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/common.js"), "html", null, true);
        echo "\"></script>
";
        // line 390
        echo "
        ";
        // line 391
        $this->displayBlock('javascripts', $context, $blocks);
        // line 393
        echo "
    </body>
</html>
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 5
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "GESTISCOUT - ";
        $this->displayBlock('titre', $context, $blocks);
        echo " ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function block_titre($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "titre"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "titre"));

        echo " ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 23
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 24
        echo "            <style>
                ul {
                    list-style-type: none;
                }
            </style>
        ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 372
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 391
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        echo "  ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  538 => 391,  520 => 372,  505 => 24,  495 => 23,  456 => 5,  443 => 393,  441 => 391,  438 => 390,  434 => 388,  429 => 386,  424 => 384,  418 => 381,  408 => 373,  406 => 372,  394 => 362,  390 => 355,  386 => 348,  382 => 341,  376 => 332,  371 => 322,  367 => 321,  350 => 306,  344 => 303,  340 => 302,  337 => 301,  335 => 300,  331 => 298,  326 => 295,  315 => 281,  311 => 280,  301 => 273,  297 => 272,  291 => 268,  288 => 265,  286 => 264,  280 => 260,  275 => 258,  271 => 257,  267 => 255,  265 => 254,  261 => 252,  256 => 250,  252 => 249,  247 => 247,  243 => 246,  240 => 245,  238 => 244,  234 => 242,  229 => 240,  225 => 239,  221 => 238,  217 => 237,  214 => 236,  212 => 235,  206 => 232,  202 => 231,  192 => 223,  188 => 220,  185 => 217,  136 => 171,  128 => 58,  123 => 55,  117 => 50,  104 => 39,  99 => 30,  97 => 23,  91 => 20,  86 => 17,  82 => 15,  78 => 14,  74 => 13,  69 => 11,  65 => 10,  61 => 9,  54 => 5,  48 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\">
        <title>{% block title %}GESTISCOUT - {% block titre %} {% endblock %} {% endblock %}</title>
        <link rel=\"icon\" href=\"favicon.ico\" type=\"image/x-icon\">
<!-- VENDOR CSS -->
        <!-- VENDOR CSS -->
        <link rel=\"stylesheet\" href=\"{{ asset('assets/vendor/bootstrap/css/bootstrap.min.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('assets/vendor/font-awesome/css/font-awesome.min.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('assets/vendor/animate-css/vivify.min.css') }}\">

        <link rel=\"stylesheet\" href=\"{{ asset('assets/vendor/c3/c3.min.css')  }}\"/>
        <link rel=\"stylesheet\" href=\"{{ asset('assets/vendor/chartist/css/chartist.min.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('assets/vendor/chartist-plugin-tooltip/chartist-plugin-tooltip.css') }}\">
{#        <link rel=\"stylesheet\" href=\"{{ asset('bundles/mercuryseriesflashy/css/flashy.css') }}\"/>#}


        <!-- MAIN CSS -->
        <link rel=\"stylesheet\" href=\"{{ asset('site.min.css') }}\">


        {% block stylesheets %}
            <style>
                ul {
                    list-style-type: none;
                }
            </style>
        {% endblock %}
    </head>
    <body class=\"theme-blue\">
        <!-- Page Loader -->
{#<div class=\"page-loader-wrapper\">#}
{#    <div class=\"loader\">#}
{#        <div class=\"m-t-30\"><i class=\"fa fa-cube font-25\"></i></div>#}
{#        <p>Veuillez patientez svp...</p>#}
{#    </div>#}
{#</div>#}

<!-- Overlay For Sidebars -->
<div class=\"overlay\"></div>
<div id=\"wrapper\">

    <nav class=\"navbar navbar-fixed-top\">
        <div class=\"container-fluid\">

            <div class=\"navbar-left\">
                <div class=\"navbar-brand\">
                    <a class=\"small_menu_btn\" href=\"javascript:void(0);\"><i class=\"fa fa-align-left\"></i></a>
                    <a href=\"{{ path(\"Dashboard\") }}\"><span>GestiScout</span></a>
                </div>
                <form id=\"navbar-search\" class=\"navbar-form search-form\">
{#                    <input value=\"\" class=\"form-control\" placeholder=\"Search here...\" type=\"text\">#}
{#                    <button type=\"button\" class=\"btn btn-default\"><i class=\"icon-magnifier\"></i></button>#}

                </form>
            </div>
            <h3 class=\"text-white\"><strong>{{ app.user.Groupe.getNom }}</strong></h3>
            <div class=\"navbar-right\">
                <div id=\"navbar-menu\">

                    <ul class=\"nav navbar-nav\">
{#                        <li class=\"dropdown\">#}
{#                            <a href=\"javascript:void(0);\" class=\"dropdown-toggle icon-menu\" data-toggle=\"dropdown\"><i class=\"fa fa-envelope\"></i>#}
{#                                <span class=\"notification-dot bg-green\"></span>#}
{#                            </a>#}
{#                            <ul class=\"dropdown-menu right_chat email vivify fadeIn\">#}
{#                                <li class=\"header\">You have 4 New eMail</li>#}
{#                                <li>#}
{#                                    <a href=\"javascript:void(0);\">#}
{#                                        <div class=\"media\">#}
{#                                            <div class=\"avtar-pic w35 lbg-indigo\"><span>FC</span></div>#}
{#                                            <div class=\"media-body\">#}
{#                                                <span class=\"name\">Folisise Chosielie <small class=\"float-right\">12min ago</small></span>#}
{#                                                <span class=\"message\">New Messages</span>#}
{#                                            </div>#}
{#                                        </div>#}
{#                                    </a>#}
{#                                </li>#}
{#                                <li>#}
{#                                    <a href=\"javascript:void(0);\">#}
{#                                        <div class=\"media\">#}
{#                                            <img class=\"media-object\" src=\"{{ asset(\"assets/images/xs/avatar5.jpg\") }}\" alt=\"\">#}
{#                                            <div class=\"media-body\">#}
{#                                                <span class=\"name\">Louis Henry <small class=\"float-right\">38min ago</small></span>#}
{#                                                <span class=\"message\">Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris.</span>#}
{#                                            </div>#}
{#                                        </div>#}
{#                                    </a>#}
{#                                </li>#}
{#                                <li>#}
{#                                    <a href=\"javascript:void(0);\">#}
{#                                        <div class=\"media\">#}
{#                                            <div class=\"avtar-pic w35 lbg-red\"><span>FC</span></div>#}
{#                                            <div class=\"media-body\">#}
{#                                                <span class=\"name\">James Wert <small class=\"float-right\">Just now</small></span>#}
{#                                                <span class=\"message\">It is a long established fact that a reader will be distracted</span>#}
{#                                            </div>#}
{#                                        </div>#}
{#                                    </a>#}
{#                                </li>#}
{#                                <li>#}
{#                                    <a href=\"javascript:void(0);\">#}
{#                                        <div class=\"media\">#}
{#                                            <div class=\"avtar-pic w35 lbg-green\"><span>FC</span></div>#}
{#                                            <div class=\"media-body\">#}
{#                                                <span class=\"name\">James Wert <small class=\"float-right\">Just now</small></span>#}
{#                                                <span class=\"message\">The point of using Lorem Ipsum is that it has a more</span>#}
{#                                            </div>#}
{#                                        </div>#}
{#                                    </a>#}
{#                                </li>#}
{#                                <li>#}
{#                                    <a href=\"javascript:void(0);\">#}
{#                                        <div class=\"media mb-0\">#}
{#                                            <img class=\"media-object\" src=\"../assets/images/xs/avatar2.jpg\" alt=\"\">#}
{#                                            <div class=\"media-body\">#}
{#                                                <span class=\"name\">Debra Stewart <small class=\"float-right\">2hr ago</small></span>#}
{#                                                <span class=\"message\">Nullam vel sem. Nullam vel sem.</span>#}
{#                                            </div>#}
{#                                        </div>#}
{#                                    </a>#}
{#                                </li>#}
{#                            </ul>#}
{#                        </li>#}
{#                        <li class=\"dropdown\">#}
{#                            <a href=\"javascript:void(0);\" class=\"dropdown-toggle icon-menu\" data-toggle=\"dropdown\"><i class=\"fa fa-bell\"></i>#}
{#                                <span class=\"notification-dot bg-azura\"></span>#}
{#                            </a>#}
{#                            <ul class=\"dropdown-menu feeds_widget vivify fadeIn\">#}
{#                                <li class=\"header\">You have 4 New Notifications</li>#}
{#                                <li>#}
{#                                    <a href=\"javascript:void(0);\">#}
{#                                        <div class=\"feeds-left lbg-red\"><i class=\"fa fa-check\"></i></div>#}
{#                                        <div class=\"feeds-body\">#}
{#                                            <h4 class=\"title text-danger\">Issue Fixed <small class=\"float-right text-muted\">9:10 AM</small></h4>#}
{#                                            <small>WE have fix all Design bug with Responsive</small>#}
{#                                        </div>#}
{#                                    </a>#}
{#                                </li>#}
{#                                <li>#}
{#                                    <a href=\"javascript:void(0);\">#}
{#                                        <div class=\"feeds-left lbg-info\"><i class=\"fa fa-user\"></i></div>#}
{#                                        <div class=\"feeds-body\">#}
{#                                            <h4 class=\"title text-info\">New User <small class=\"float-right text-muted\">9:15 AM</small></h4>#}
{#                                            <small>I feel great! Thanks team</small>#}
{#                                        </div>#}
{#                                    </a>#}
{#                                </li>#}
{#                                <li>#}
{#                                    <a href=\"javascript:void(0);\">#}
{#                                        <div class=\"feeds-left lbg-orange\"><i class=\"fa fa-question-circle\"></i></div>#}
{#                                        <div class=\"feeds-body\">#}
{#                                            <h4 class=\"title text-warning\">Server Warning <small class=\"float-right text-muted\">9:17 AM</small></h4>#}
{#                                            <small>Your connection is not private</small>#}
{#                                        </div>#}
{#                                    </a>#}
{#                                </li>#}
{#                                <li>#}
{#                                    <a href=\"javascript:void(0);\">#}
{#                                        <div class=\"feeds-left lbg-green\"><i class=\"fa fa-thumbs-o-up\"></i></div>#}
{#                                        <div class=\"feeds-body\">#}
{#                                            <h4 class=\"title text-success\">2 New Feedback <small class=\"float-right text-muted\">9:22 AM</small></h4>#}
{#                                            <small>It will give a smart finishing to your site</small>#}
{#                                        </div>#}
{#                                    </a>#}
{#                                </li>#}
{#                            </ul>#}
{#                        </li>#}
{#                        <li><a href=\"javascript:void(0);\" class=\"right_toggle icon-menu\" title=\"Right Menu\"><i class=\"fa fa-comments\"></i><span class=\"notification-dot bg-pink\"></span></a></li>#}
                        <li><a href=\"{{ path('app_logout') }}\" class=\"icon-menu\"><i class=\"fa fa-power-off\"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>
    <div id=\"rightbar\" class=\"rightbar\">
        <div class=\"slim_scroll\">
            <div class=\"chat_detail vivify fadeIn delay-100\">
                <ul class=\"chat-widget clearfix\">
                    <li class=\"left float-left\">
                        <div class=\"avtar-pic w35 bg-pink\"><span>KG</span></div>
                        <div class=\"chat-info\">
                            <span class=\"message\">Hello, John<br>What is the update on Project X?</span>
                        </div>
                    </li>
                    <li class=\"right\">
                        <img src=\"../assets/images/xs/avatar1.jpg\" class=\"rounded\" alt=\"\">
                        <div class=\"chat-info\">
                            <span class=\"message\">Hi, Alizee<br> It is almost completed. I will send you an email later today.</span>
                        </div>
                    </li>
                    <li class=\"left float-left\">
                        <div class=\"avtar-pic w35 bg-pink\"><span>KG</span></div>
                        <div class=\"chat-info\">
                            <span class=\"message\">That's great. Will catch you in evening.</span>
                        </div>
                    </li>
                    <li class=\"right\">
                        <img src=\"../assets/images/xs/avatar1.jpg\" class=\"rounded\" alt=\"\">
                        <div class=\"chat-info\">
                            <span class=\"message\">Sure we'will have a blast today.</span>
                        </div>
                    </li>
                </ul>
                <div class=\"input-group p-t-15\">
                    <textarea rows=\"3\" class=\"form-control\" placeholder=\"Enter text here...\"></textarea>
                </div>
            </div>
        </div>
    </div>
    <div id=\"left-sidebar\" class=\"sidebar\">

        <div class=\"sidebar_icon\">
            <ul class=\"nav nav-tabs\">
{#                <li class=\"nav-item\"><a class=\"nav-link\" href=\"page-search-results.html\"><i class=\"fa fa-search\"></i></a></li>#}
                <li class=\"nav-item\"><a class=\"nav-link active\" data-toggle=\"tab\" href=\"#Home-icon\"><i class=\"fa fa-dashboard\"></i></a></li>
{#                <li class=\"nav-item\"><a class=\"nav-link\" data-toggle=\"tab\" href=\"#Envelope-icon\"><i class=\"fa fa-envelope\"></i></a></li>#}
{#                <li class=\"nav-item\"><a class=\"nav-link\" data-toggle=\"tab\" href=\"#Components-icon\"><i class=\"icon-diamond\"></i></a></li>#}
                <li class=\"nav-item\">
                    <a class=\"nav-link\" data-toggle=\"tab\" href=\"#Profile-icon\"><i class=\"fa fa-user\"></i></a>
{#                    <a class=\"nav-link\" data-toggle=\"tab\" href=\"#Setting-icon\"><i class=\"fa fa-cog\"></i></a>#}
                </li>
            </ul>
        </div>
        <div class=\"sidebar_list\">
            <div class=\"tab-content\" id=\"main-menu\">
                <div class=\"tab-pane active\" id=\"Home-icon\">
                    <nav class=\"sidebar-nav sidebar-scroll\">
                        <ul class=\"metismenu\">
                            <li class=><img src=\"{{ asset(\"/img_logo/LOGO.jpg\") }}\" class=\"img-fluid\" WIDTH=\"170\" height=\"150\"></li>
                            <li class=\"active\"><a href=\"{{ path(\"Dashboard\") }}\"><i class=\"fa fa-dashboard\"></i><span>Dashboard</span></a></li>


                            {% if is_granted('ROLE_SUPERADMIN') %}
                            <li class=\"header\">Configuration</li>
                            <li><a href=\"{{  path(\"ListeAnnePastorale\") }}\"><i class=\"fa fa-wrench\"></i><span>Année pastorale</span></a></li>
                            <li><a href=\"{{  path(\"ListeBranche\") }}\"><i class=\"fa fa-wrench\"></i><span>Branche</span></a></li>
                            <li><a href=\"{{ path(\"ListeFonction\") }}\"><i class=\"fa fa-wrench\"></i><span>Fonction</span></a></li>
                                <li><a href=\"{{ path(\"Groupe\") }}\"><i class=\"fa fa-wrench\"></i><span>Groupe</span></a></li>
                            {% endif %}


                            {% if is_granted('ROLE_CG') %}
                            <li class=\"header\">Jeunes</li>
                            <li><a href=\"{{ path(\"AddJeune\") }}\"><i class=\"fa fa-plus\"></i><span>Nouveau jeune</span></a></li>
                            <li><a href=\"{{ path(\"ListeJeunes\") }}\"><i class=\"fa fa-list\"></i><span>Liste des jeunes</span></a></li>
                             <li class=\"header\">Responsable</li>
                            <li><a href=\"{{ path(\"AjouterRespoView\") }}\"><i class=\"fa fa-plus\"></i><span>Nouveau responsable</span></a></li>
                            <li><a href=\"{{ path(\"responsable\") }}\"><i class=\"fa fa-list\"></i><span>Liste des responsables</span></a></li>
                            {% endif %}


                        {% if is_granted('ROLE_ADMIN') %}

                            <li class=\"header\">Responsable</li>
                            <li><a href=\"{{ path(\"AjouterRespoView\") }}\"><i class=\"fa fa-plus\"></i><span>Nouveau responsable</span></a></li>
                            <li><a href=\"{{ path(\"responsable\") }}\"><i class=\"fa fa-list\"></i><span>Liste des responsables</span></a></li>
                        {% endif %}




                            {% if is_granted('ROLE_CG') %}
                                <li class=\"header\">Cotisation</li>
{#                                <li><a href=\"{{  path(\"cotisation\") }}\"><i class=\"fa fa-money\"></i><span>Faire une cotisation</span></a></li>#}
{#                                <li><a href=\"{{ path(\"ViewJeuneCotise\") }}\"><i class=\"fa fa-list\"></i><span>Liste des cotisés</span></a></li>#}

                                <li>
                                <a href=\"#Tables\" class=\"has-arrow\"><i class=\"fa fa-plus-circle\"></i><span>Cotisation Jeune</span></a>
                                <ul>
                                    <li><a href=\"{{  path(\"cotisation\") }}\">Faire une cotisation</a></li>
                                    <li><a href=\"{{ path(\"ViewJeuneCotise\") }}\">Liste des cotisés</a></li>

                                </ul>
                                </li>
                                <li>
                                    <a href=\"#Tables1\" class=\"has-arrow\"><i class=\"fa fa-plus-circle\"></i><span>Cotisation Chef</span></a>
                                    <ul>
                                        <li><a href=\"{{  path(\"cotisationResponsable\") }}\">Faire une cotisation</a></li>
                                        <li><a href=\"{{ path(\"ViewResponsableCotise\") }}\">Liste des cotisés</a></li>
                                    </ul>
                                </li>





{# 
                                <li class=\"header\">Importation données</li>



                                        <li><a href=\"{{  path(\"ImportJeune\") }}\"><i class=\"fa fa-download\"></i><span>Importation Jeune</span></a></li> #}


                            {% endif %}


                            {% if is_granted('ROLE_CONSULTANT') %}
                                <li class=\"header\">Jeunes</li>
                                <li><a href=\"{{ path(\"ListeJeunes\") }}\"><i class=\"fa fa-list\"></i><span>Liste des jeunes</span></a></li>
                                <li><a href=\"{{ path(\"ViewJeuneCotise\") }}\"><i class=\"fa fa-list\"></i><span>Liste des cotisés</span></a></li>

                            {% endif %}







                        </ul>
                    </nav>
                </div>
                <div class=\"tab-pane\" id=\"Profile-icon\">
                    <nav class=\"sidebar-nav sidebar-scroll\">
                        <div class=\"user-detail\">
                            <div class=\"text-center mb-3\">
                                <img class=\"img-thumbnail rounded-circle\" src=\"../assets/images/sm/avatar1.jpg\" alt=\"\">
                                <h6 class=\"mt-3 mb-0\">{{ app.user.responsable.getNom }}</h6>
                                <div class=\"text-center text-muted\">{{ app.user.responsable.getPrenoms }}</div>
                                <hr>
{#                                <small class=\"text-muted\">Address: </small>#}
{#                                <p> San Francisco</p>#}
{#                                <small class=\"text-muted\">Email address: </small>#}
{#                                <p>louispierce@example.com</p>#}
{#                                <small class=\"text-muted\">Mobile: </small>#}
{#                                <p>+ 202-222-2121</p>#}
{#                                <a href=\"page-profile.html\" class=\"btn btn-block btn-success mb-2\" title=\"\">View Profile</a>#}
{#                                <a href=\"../documentation/index.html\" class=\"btn btn-block btn-info\">Documentation</a>#}
                            </div>
                            <hr>
                            <div class=\"card-text\">
                                <div class=\"mt-0\">
{#                                    <small class=\"float-right text-muted\">10/200 GB</small>#}
{#                                    <span>Memory</span>#}
{#                                    <div class=\"progress progress-xxs\">#}
{#                                        <div style=\"width: 60%;\" class=\"progress-bar\"></div>#}
{#                                    </div>#}
                                </div>
                                <div class=\"mt-4\">
{#                                    <small class=\"float-right text-muted\">40 MB</small>#}
{#                                    <span>Bandwidth</span>#}
{#                                    <div class=\"progress progress-xxs\">#}
{#                                        <div style=\"width: 50%;\" class=\"progress-bar\"></div>#}
{#                                    </div>#}
                                </div>
                                <div class=\"mt-4\">
{#                                    <small class=\"float-right text-muted\">73%</small>#}
{#                                    <span>Activity</span>#}
{#                                    <div class=\"progress progress-xxs\">#}
{#                                        <div style=\"width: 40%;\" class=\"progress-bar\"></div>#}
{#                                    </div>#}
                                </div>
                                <div class=\"mt-4\">
{#                                    <small class=\"float-right text-muted\">400 GB</small>#}
{#                                    <span>FTP</span>#}
{#                                    <div class=\"progress progress-xxs mb-0\">#}
{#                                        <div style=\"width: 80%;\" class=\"progress-bar bg-danger\"></div>#}
{#                                    </div>#}
                                </div>
                            </div>
                        </div>
                    </nav>
                </div>

            </div>
        </div>
    </div>
    <div id=\"main-content\">
        {% block body %}{% endblock %}

    </div>
</div>





            <script src=\"{{ asset('assets/vendor/jquery/jquery-3.3.1.min.js') }}\"></script>


            <script src=\"{{ asset('assets/vendor/bootstrap/js/bootstrap.bundle.min.js') }}\"></script>

            <script src=\"{{ asset('bundles/vendorscripts.bundle.js') }}\"></script>

            <script src=\"{{ asset('js/common.js') }}\"></script>
{#            <script src=\"{{ asset('bundles/mercuryseriesflashy/js/flashy.js') }}\"></script>#}

        {% block javascripts %}  {% endblock %}
{#        {{ include('@MercurySeriesFlashy/flashy.html.twig') }}#}

    </body>
</html>
", "base.html.twig", "D:\\CODES SOURCES\\SYMFONY\\GestiScoutWeb\\templates\\base.html.twig");
    }
}

<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* jeune/AddJeune.html.twig */
class __TwigTemplate_4fc94400cf5bf691148b0775788f09bf7cc4a212cbb6403c225783e4759ec280 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'stylesheets' => [$this, 'block_stylesheets'],
            'titre' => [$this, 'block_titre'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "jeune/AddJeune.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "jeune/AddJeune.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "jeune/AddJeune.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 3
        echo "<link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/jquery-datatable/dataTables.bootstrap4.min.css"), "html", null, true);
        echo "\"/>
<link rel=\"stylesheet\" href=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/sweetalert/sweetalert.css"), "html", null, true);
        echo "\"/>

    <style>
        .bd-example-modal-lg .modal-dialog{
            display: table;
            position: relative;
            margin: 0 auto;
            top: calc(50% - 24px);
        }

        .bd-example-modal-lg .modal-dialog .modal-content{
            background-color: transparent;
            border: none;
        }


    </style>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 22
    public function block_titre($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "titre"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "titre"));

        echo " Ajouter un jeune ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 24
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 25
        echo "
    <input type=\"hidden\" value=\"";
        // line 26
        echo twig_escape_filter($this->env, (isset($context["groupeid"]) || array_key_exists("groupeid", $context) ? $context["groupeid"] : (function () { throw new RuntimeError('Variable "groupeid" does not exist.', 26, $this->source); })()), "html", null, true);
        echo "\" id=\"gr\" disabled> 
    <div class=\"block-header\">
        <div class=\"row clearfix\">
            <div class=\"col-md-6 col-sm-12\">

                <nav aria-label=\"breadcrumb\">
                    <ol class=\"breadcrumb\">
";
        // line 36
        echo "                    </ol>
                </nav>
            </div>
            <div class=\"col-md-6 col-sm-12 text-right hidden-xs\">
";
        // line 41
        echo "            </div>
        </div>
    </div>


    <div class=\"container-fluid\">
        <div class=\"row clearfix\">
            <div class=\"col-lg-12\">
                <div class=\"col-lg-12\">
                    <div class=\"card\">
                        <div class=\"header text-center\">
                            <h2>Ajouter un jeune</h2>
                        </div>
                        <div class=\"body\">





                            <div class=\"row\">
                                <div class=\"col-lg-6\">
                                    <form id=\"basic-form\" method=\"post\" novalidate>
                                        <div class=\"form-group\">
                                            <label>Nom</label>
                                            <input type=\"text\" class=\"form-control\" required id=\"Nom\">
                                        </div>
                                        <div class=\"form-group\">
                                            <label>Prénoms</label>
                                            <input type=\"text\" class=\"form-control\" required id=\"prenoms\">
                                        </div>
                                        <div class=\"form-group\">
                                            <label>Genre</label>
                                            <select id=\"genre\" class=\"form-control\"></select>
                                        </div>
                                        <div class=\"form-group\">
                                            <label>Date de naissance</label>
                                            <div class=\"\">
                                            <input type=\"date\" class=\"form-control \" required id=\"dob\" max=\"\">
";
        // line 80
        echo "                                            </div>
                                        </div>
                                        <div class=\"form-group\">
                                            <label>Lieu d'habitation</label>
                                            <input type=\"text\" class=\"form-control\" required id=\"habitation\">
                                        </div>
                                        <div class=\"form-group\">
                                            <label>Occupation</label>
                                            <input type=\"text\" class=\"form-control\" required id=\"occupation\">
                                        </div>


                                        <br>

                                    </form>
                                </div>
                                <div class=\"col-lg-6\">
                                    <form id=\"basic-form\" method=\"post\" novalidate>
                                        <div class=\"form-group\">
                                            <label>Téléphone</label>
                                            <input type=\"tel\" id=\"phone\" class=\"form-control\"/>
                                        </div>
                                        <div class=\"form-group\">
                                            <label>Nom Père</label>
                                            <input type=\"text\" class=\"form-control\" required id=\"NomPere\">
                                        </div>
                                        <div class=\"form-group\">
                                            <label>Numéro Père</label>
                                            <input type=\"tel\" class=\"form-control\" required id=\"NumPere\">
                                        </div>
                                        <div class=\"form-group\">
                                            <label>Nom Mère</label>
                                            <input type=\"text\" class=\"form-control\" required id=\"NomMere\">
                                        </div>
                                        <div class=\"form-group\">
                                            <label>Numéro Mère</label>
                                            <input type=\"tel\" class=\"form-control\" required id=\"NumMere\">
                                        </div>
                                        <div class=\"form-group\">
                                            <label>Branche</label>
                                            <select id=\"branche\" class=\"form-control\"></select>
                                        </div>
                                        <div class=\"form-group\">
                                            <label>Groupe</label>
                                            <select id=\"groupe\" class=\"form-control\" readonly></select>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class=\"text-center\">
                                <button type=\"button\" class=\"btn btn-success\" id=\"save\">Enregistrer</button>
                                <button type=\"button\" class=\"btn btn-danger\" id=\"reset\">Annuler</button>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class=\"modal fade bd-example-modal-lg\" data-backdrop=\"static\" data-keyboard=\"false\" tabindex=\"-1\">
        <div class=\"modal-dialog modal-sm\">
            <div class=\"modal-content\" style=\"width: 48px\">
                <span class=\"fa fa-spinner fa-spin fa-3x\"></span>
            </div>
        </div>
    </div>



";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 154
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 155
        echo "<script src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/jquery-datatable/jquery.dataTables.min.js"), "html", null, true);
        echo "\"></script>
<script src=\"";
        // line 156
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/sweetalert/sweetalert.min.js"), "html", null, true);
        echo "\"></script>

<script>
    \$(document).ready(function(){
        debugger
        
        let currentdate = CurrentDate();
        document.getElementById(\"dob\").setAttribute(\"max\", currentdate);
        function CurrentDate(){
            let today = new Date();
            let dd = String(today.getDate()).padStart(2, '0');
            let mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
            let yyyy = today.getFullYear();
            today = yyyy + '-' + mm + '-' + dd;
            return today;
        }
        \$(\"#modal\").modal(\"show\");
reset();
        function loading()
        {
            \$('.modal').modal('show');

        }
        function loadingClose()
        {
            \$('.modal').modal('hide');

        }
        function reset(){
               \$(\"#Nom\").val('');
                    \$(\"#prenoms\").val('');
                    \$(\"#dob\").val('');
                    \$(\"#habitation\").val('');
                    \$(\"#NomPere\").val('');
                    \$(\"#NumPere\").val('');
                    \$(\"#NomMere\").val('');
                    \$(\"#NumMere\").val('');
                     \$.ajax({
                type:\"GET\",
                url:\"";
        // line 195
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("GetListBranche");
        echo "\",
                success:function(resp){
                    debugger
                    \$(\"#branche\").empty();
                    var defaultline = '<option value=selected>---selectionner branche---</option>';
                    \$(\"#branche\").append(defaultline);
                    var liste = JSON.parse(resp);
                    \$.each(liste,function(i,n){
                        debugger
                        var line = '<option value='+n.id+'>'+n.Libelle+'</option>';
                        \$(\"#branche\").append(line);

                    });
                }
            });
                     \$.ajax({
                type:\"GET\",
                url:\"";
        // line 212
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("GetListGroupe");
        echo "\",
                success:function(resp){
                    debugger
                    \$(\"#groupe\").empty();
                    var defaultline = '<option value=selected>---selectionner groupe---</option>';
                    \$(\"#groupe\").append(defaultline);
                    var liste = JSON.parse(resp);
                    \$.each(liste,function(i,n){
                        debugger
                        var line = '<option value='+n.id+'>'+n.Nom+'</option>';
                        \$(\"#groupe\").append(line);

                    });
                    \$(\"#groupe\").val(\$(\"#gr\").val());
                }
            });
                     \$.ajax({
                type:\"GET\",
                url:\"";
        // line 230
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("GetListeGenre");
        echo "\",
                success:function(resp){
                    debugger
                    var defaultline = '<option value=selected>---selectionner genre---</option>';
                    \$(\"#genre\").append(defaultline);
                   var liste = JSON.parse(resp);
                    \$.each(liste,function(i,n){
                        debugger
                        var line = '<option value='+n.id+'>'+n.Libelle+'</option>';
                        \$(\"#genre\").append(line);

                    });
                }
            });
        }
        \$(\"#save\").click(function(){
           //alert(\"hello\");
        debugger
            loading();
         var  jeune={
               nom : \$(\"#Nom\").val(),
               prenoms : \$(\"#prenoms\").val(),
               dob : \$(\"#dob\").val(),
               occupation : \$(\"#occupation\").val(),
               habitation : \$(\"#habitation\").val(),
               NomPere : \$(\"#NomPere\").val(),
               NumPere: \$(\"#NumPere\").val(),
               NomMere : \$(\"#NomMere\").val(),
               NumMere : \$(\"#NumMere\").val(),
               branche : \$(\"#branche\").val(),
               Groupe : \$(\"#groupe\").val(),
               phone : \$(\"#phone\").val(),
               genre: \$(\"#genre\").val()
           };
        //    loading();
           \$.ajax({
            type:\"POST\",
            async: true,
            dataType: 'json',
            url:\"";
        // line 269
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AddJeuneFunction");
        echo "\",
            data: {value : jeune},
            success:function(res){
                loadingClose();
debugger;
if (res==true){
//loadingClose();
                swal({
                    type:\"success\",
                    title:\"JEUNE\",
                    text:\"Enregistrement effectué avec succès\"
                },function (){
                   loadingClose();
                    reset();

                });
                }else {
   // loadingClose();
    swal({
        title:'',
        type:\"error\",
        text:\"Echec de l'opération\"
    });
}
            },
               error:function(res){
                debugger
              //  loadingClose();
                   swal({
                       title:'',
                       type:\"error\",
                       text:\"Echec de l'opération \"+res.responseText
                   });
               }

           });

loadingClose();
        });
        \$(\"#reset\").click(function(){

            swal({
                title: 'Annulation',
                text: \"Etes-vous sûr de vouloir annuler ?\",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Oui annuler!',
                cancelButtonText:\"Non\"
            },function(res){
                debugger
                if(res==true)
                    reset();

            });



        //    reset();
        });


    });
</script>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "jeune/AddJeune.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  413 => 269,  371 => 230,  350 => 212,  330 => 195,  288 => 156,  283 => 155,  273 => 154,  192 => 80,  152 => 41,  146 => 36,  136 => 26,  133 => 25,  123 => 24,  104 => 22,  76 => 4,  71 => 3,  61 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}
{% block stylesheets %}
<link rel=\"stylesheet\" href=\"{{ asset('assets/vendor/jquery-datatable/dataTables.bootstrap4.min.css') }}\"/>
<link rel=\"stylesheet\" href=\"{{ asset('assets/vendor/sweetalert/sweetalert.css') }}\"/>

    <style>
        .bd-example-modal-lg .modal-dialog{
            display: table;
            position: relative;
            margin: 0 auto;
            top: calc(50% - 24px);
        }

        .bd-example-modal-lg .modal-dialog .modal-content{
            background-color: transparent;
            border: none;
        }


    </style>
{% endblock %}
{% block titre %} Ajouter un jeune {% endblock %}

{% block body %}

    <input type=\"hidden\" value=\"{{groupeid}}\" id=\"gr\" disabled> 
    <div class=\"block-header\">
        <div class=\"row clearfix\">
            <div class=\"col-md-6 col-sm-12\">

                <nav aria-label=\"breadcrumb\">
                    <ol class=\"breadcrumb\">
{#                        <li class=\"breadcrumb-item\"><a href=\"#\"><i class=\"fa fa-cube\"></i></a></li>#}
{#                        <li class=\"breadcrumb-item\"><a href=\"#\">Liste des responsables</a></li>#}
{#                        <li class=\"breadcrumb-item active\" aria-current=\"page\">Color Table</li>#}
                    </ol>
                </nav>
            </div>
            <div class=\"col-md-6 col-sm-12 text-right hidden-xs\">
{#                <a href=\"javascript:void(0);\" class=\"btn btn-sm btn-primary\" title=\"\">Ajouter un responsable</a>#}
            </div>
        </div>
    </div>


    <div class=\"container-fluid\">
        <div class=\"row clearfix\">
            <div class=\"col-lg-12\">
                <div class=\"col-lg-12\">
                    <div class=\"card\">
                        <div class=\"header text-center\">
                            <h2>Ajouter un jeune</h2>
                        </div>
                        <div class=\"body\">





                            <div class=\"row\">
                                <div class=\"col-lg-6\">
                                    <form id=\"basic-form\" method=\"post\" novalidate>
                                        <div class=\"form-group\">
                                            <label>Nom</label>
                                            <input type=\"text\" class=\"form-control\" required id=\"Nom\">
                                        </div>
                                        <div class=\"form-group\">
                                            <label>Prénoms</label>
                                            <input type=\"text\" class=\"form-control\" required id=\"prenoms\">
                                        </div>
                                        <div class=\"form-group\">
                                            <label>Genre</label>
                                            <select id=\"genre\" class=\"form-control\"></select>
                                        </div>
                                        <div class=\"form-group\">
                                            <label>Date de naissance</label>
                                            <div class=\"\">
                                            <input type=\"date\" class=\"form-control \" required id=\"dob\" max=\"\">
{#                                          <input class=\"col-lg-3\" type=\"text\" disabled=\"disabled\" value=\"d\">#}
                                            </div>
                                        </div>
                                        <div class=\"form-group\">
                                            <label>Lieu d'habitation</label>
                                            <input type=\"text\" class=\"form-control\" required id=\"habitation\">
                                        </div>
                                        <div class=\"form-group\">
                                            <label>Occupation</label>
                                            <input type=\"text\" class=\"form-control\" required id=\"occupation\">
                                        </div>


                                        <br>

                                    </form>
                                </div>
                                <div class=\"col-lg-6\">
                                    <form id=\"basic-form\" method=\"post\" novalidate>
                                        <div class=\"form-group\">
                                            <label>Téléphone</label>
                                            <input type=\"tel\" id=\"phone\" class=\"form-control\"/>
                                        </div>
                                        <div class=\"form-group\">
                                            <label>Nom Père</label>
                                            <input type=\"text\" class=\"form-control\" required id=\"NomPere\">
                                        </div>
                                        <div class=\"form-group\">
                                            <label>Numéro Père</label>
                                            <input type=\"tel\" class=\"form-control\" required id=\"NumPere\">
                                        </div>
                                        <div class=\"form-group\">
                                            <label>Nom Mère</label>
                                            <input type=\"text\" class=\"form-control\" required id=\"NomMere\">
                                        </div>
                                        <div class=\"form-group\">
                                            <label>Numéro Mère</label>
                                            <input type=\"tel\" class=\"form-control\" required id=\"NumMere\">
                                        </div>
                                        <div class=\"form-group\">
                                            <label>Branche</label>
                                            <select id=\"branche\" class=\"form-control\"></select>
                                        </div>
                                        <div class=\"form-group\">
                                            <label>Groupe</label>
                                            <select id=\"groupe\" class=\"form-control\" readonly></select>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class=\"text-center\">
                                <button type=\"button\" class=\"btn btn-success\" id=\"save\">Enregistrer</button>
                                <button type=\"button\" class=\"btn btn-danger\" id=\"reset\">Annuler</button>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class=\"modal fade bd-example-modal-lg\" data-backdrop=\"static\" data-keyboard=\"false\" tabindex=\"-1\">
        <div class=\"modal-dialog modal-sm\">
            <div class=\"modal-content\" style=\"width: 48px\">
                <span class=\"fa fa-spinner fa-spin fa-3x\"></span>
            </div>
        </div>
    </div>



{% endblock %}


{% block javascripts %}
<script src=\"{{ asset('assets/vendor/jquery-datatable/jquery.dataTables.min.js') }}\"></script>
<script src=\"{{ asset('assets/vendor/sweetalert/sweetalert.min.js') }}\"></script>

<script>
    \$(document).ready(function(){
        debugger
        
        let currentdate = CurrentDate();
        document.getElementById(\"dob\").setAttribute(\"max\", currentdate);
        function CurrentDate(){
            let today = new Date();
            let dd = String(today.getDate()).padStart(2, '0');
            let mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
            let yyyy = today.getFullYear();
            today = yyyy + '-' + mm + '-' + dd;
            return today;
        }
        \$(\"#modal\").modal(\"show\");
reset();
        function loading()
        {
            \$('.modal').modal('show');

        }
        function loadingClose()
        {
            \$('.modal').modal('hide');

        }
        function reset(){
               \$(\"#Nom\").val('');
                    \$(\"#prenoms\").val('');
                    \$(\"#dob\").val('');
                    \$(\"#habitation\").val('');
                    \$(\"#NomPere\").val('');
                    \$(\"#NumPere\").val('');
                    \$(\"#NomMere\").val('');
                    \$(\"#NumMere\").val('');
                     \$.ajax({
                type:\"GET\",
                url:\"{{ path(\"GetListBranche\")}}\",
                success:function(resp){
                    debugger
                    \$(\"#branche\").empty();
                    var defaultline = '<option value=selected>---selectionner branche---</option>';
                    \$(\"#branche\").append(defaultline);
                    var liste = JSON.parse(resp);
                    \$.each(liste,function(i,n){
                        debugger
                        var line = '<option value='+n.id+'>'+n.Libelle+'</option>';
                        \$(\"#branche\").append(line);

                    });
                }
            });
                     \$.ajax({
                type:\"GET\",
                url:\"{{ path(\"GetListGroupe\")}}\",
                success:function(resp){
                    debugger
                    \$(\"#groupe\").empty();
                    var defaultline = '<option value=selected>---selectionner groupe---</option>';
                    \$(\"#groupe\").append(defaultline);
                    var liste = JSON.parse(resp);
                    \$.each(liste,function(i,n){
                        debugger
                        var line = '<option value='+n.id+'>'+n.Nom+'</option>';
                        \$(\"#groupe\").append(line);

                    });
                    \$(\"#groupe\").val(\$(\"#gr\").val());
                }
            });
                     \$.ajax({
                type:\"GET\",
                url:\"{{ path(\"GetListeGenre\")}}\",
                success:function(resp){
                    debugger
                    var defaultline = '<option value=selected>---selectionner genre---</option>';
                    \$(\"#genre\").append(defaultline);
                   var liste = JSON.parse(resp);
                    \$.each(liste,function(i,n){
                        debugger
                        var line = '<option value='+n.id+'>'+n.Libelle+'</option>';
                        \$(\"#genre\").append(line);

                    });
                }
            });
        }
        \$(\"#save\").click(function(){
           //alert(\"hello\");
        debugger
            loading();
         var  jeune={
               nom : \$(\"#Nom\").val(),
               prenoms : \$(\"#prenoms\").val(),
               dob : \$(\"#dob\").val(),
               occupation : \$(\"#occupation\").val(),
               habitation : \$(\"#habitation\").val(),
               NomPere : \$(\"#NomPere\").val(),
               NumPere: \$(\"#NumPere\").val(),
               NomMere : \$(\"#NomMere\").val(),
               NumMere : \$(\"#NumMere\").val(),
               branche : \$(\"#branche\").val(),
               Groupe : \$(\"#groupe\").val(),
               phone : \$(\"#phone\").val(),
               genre: \$(\"#genre\").val()
           };
        //    loading();
           \$.ajax({
            type:\"POST\",
            async: true,
            dataType: 'json',
            url:\"{{ path('AddJeuneFunction') }}\",
            data: {value : jeune},
            success:function(res){
                loadingClose();
debugger;
if (res==true){
//loadingClose();
                swal({
                    type:\"success\",
                    title:\"JEUNE\",
                    text:\"Enregistrement effectué avec succès\"
                },function (){
                   loadingClose();
                    reset();

                });
                }else {
   // loadingClose();
    swal({
        title:'',
        type:\"error\",
        text:\"Echec de l'opération\"
    });
}
            },
               error:function(res){
                debugger
              //  loadingClose();
                   swal({
                       title:'',
                       type:\"error\",
                       text:\"Echec de l'opération \"+res.responseText
                   });
               }

           });

loadingClose();
        });
        \$(\"#reset\").click(function(){

            swal({
                title: 'Annulation',
                text: \"Etes-vous sûr de vouloir annuler ?\",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Oui annuler!',
                cancelButtonText:\"Non\"
            },function(res){
                debugger
                if(res==true)
                    reset();

            });



        //    reset();
        });


    });
</script>

{% endblock %}
", "jeune/AddJeune.html.twig", "D:\\CODES SOURCES\\SYMFONY\\GestiScoutWeb\\templates\\jeune\\AddJeune.html.twig");
    }
}

<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* connexion/Dashboard.html.twig */
class __TwigTemplate_03eeef8433f1464de3d981c96b62490f81276e1e36c2a231a7390026288d1266 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'stylesheets' => [$this, 'block_stylesheets'],
            'titre' => [$this, 'block_titre'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "connexion/Dashboard.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "connexion/Dashboard.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "connexion/Dashboard.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 8
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 9
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/jquery-datatable/dataTables.bootstrap4.min.css"), "html", null, true);
        echo "\"/>

    <link rel=\"stylesheet\" href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("c3n/c3.css"), "html", null, true);
        echo "\"/>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 14
    public function block_titre($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "titre"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "titre"));

        echo " Tableau de bord ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 16
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 17
        echo "


    <input type=\"hidden\" id=\"louvc\" value=\"";
        // line 20
        echo twig_escape_filter($this->env, (isset($context["nbreCotiseLouveteau"]) || array_key_exists("nbreCotiseLouveteau", $context) ? $context["nbreCotiseLouveteau"] : (function () { throw new RuntimeError('Variable "nbreCotiseLouveteau" does not exist.', 20, $this->source); })()), "html", null, true);
        echo "\">
    <input type=\"hidden\" id=\"eclaic\" value=\"";
        // line 21
        echo twig_escape_filter($this->env, (isset($context["nbreCotiseEclaireur"]) || array_key_exists("nbreCotiseEclaireur", $context) ? $context["nbreCotiseEclaireur"] : (function () { throw new RuntimeError('Variable "nbreCotiseEclaireur" does not exist.', 21, $this->source); })()), "html", null, true);
        echo "\">
    <input type=\"hidden\" id=\"chemc\" value=\"";
        // line 22
        echo twig_escape_filter($this->env, (isset($context["nbreCotiseCheminot"]) || array_key_exists("nbreCotiseCheminot", $context) ? $context["nbreCotiseCheminot"] : (function () { throw new RuntimeError('Variable "nbreCotiseCheminot" does not exist.', 22, $this->source); })()), "html", null, true);
        echo "\">
    <input type=\"hidden\" id=\"routc\" value=\"";
        // line 23
        echo twig_escape_filter($this->env, (isset($context["nbreCotiseRoutier"]) || array_key_exists("nbreCotiseRoutier", $context) ? $context["nbreCotiseRoutier"] : (function () { throw new RuntimeError('Variable "nbreCotiseRoutier" does not exist.', 23, $this->source); })()), "html", null, true);
        echo "\">
    <input type=\"hidden\" id=\"louv\" value=\"";
        // line 24
        echo twig_escape_filter($this->env, (isset($context["TotalLouveteau"]) || array_key_exists("TotalLouveteau", $context) ? $context["TotalLouveteau"] : (function () { throw new RuntimeError('Variable "TotalLouveteau" does not exist.', 24, $this->source); })()), "html", null, true);
        echo "\"/>
    <input type=\"hidden\" id=\"ecl\" value=\"";
        // line 25
        echo twig_escape_filter($this->env, (isset($context["TotalEclaireur"]) || array_key_exists("TotalEclaireur", $context) ? $context["TotalEclaireur"] : (function () { throw new RuntimeError('Variable "TotalEclaireur" does not exist.', 25, $this->source); })()), "html", null, true);
        echo "\">
    <input type=\"hidden\" id=\"chem\" value=\"";
        // line 26
        echo twig_escape_filter($this->env, (isset($context["TotalCheminot"]) || array_key_exists("TotalCheminot", $context) ? $context["TotalCheminot"] : (function () { throw new RuntimeError('Variable "TotalCheminot" does not exist.', 26, $this->source); })()), "html", null, true);
        echo "\">
    <input type=\"hidden\" id=\"rout\" value=\"";
        // line 27
        echo twig_escape_filter($this->env, (isset($context["TotalRoutier"]) || array_key_exists("TotalRoutier", $context) ? $context["TotalRoutier"] : (function () { throw new RuntimeError('Variable "TotalRoutier" does not exist.', 27, $this->source); })()), "html", null, true);
        echo "\">
    <input type=\"hidden\" id=\"chefcotise\" value=\"";
        // line 28
        echo twig_escape_filter($this->env, (isset($context["TotalChefCotiseGroupe"]) || array_key_exists("TotalChefCotiseGroupe", $context) ? $context["TotalChefCotiseGroupe"] : (function () { throw new RuntimeError('Variable "TotalChefCotiseGroupe" does not exist.', 28, $this->source); })()), "html", null, true);
        echo "\"/>
    <input type=\"hidden\" id=\"respo\" value=\"";
        // line 29
        echo twig_escape_filter($this->env, (isset($context["TotalResponsable"]) || array_key_exists("TotalResponsable", $context) ? $context["TotalResponsable"] : (function () { throw new RuntimeError('Variable "TotalResponsable" does not exist.', 29, $this->source); })()), "html", null, true);
        echo "\"/>

    <div class=\"block-header\">
        <div class=\"row clearfix\">
            <div class=\"col-md-6 col-sm-12\">
                <h1>Tableau de bord</h1>


            </div>
            <div class=\"col-md-6 col-sm-12 text-right hidden-xs\">
                <h1 style=\"color=red;\">";
        // line 39
        echo twig_escape_filter($this->env, (isset($context["Annee"]) || array_key_exists("Annee", $context) ? $context["Annee"] : (function () { throw new RuntimeError('Variable "Annee" does not exist.', 39, $this->source); })()), "html", null, true);
        echo "</h1>

            </div>
        </div>
    </div>

    <div class=\"container-fluid\">


        ";
        // line 48
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_CG")) {
            // line 49
            echo "
            <div class=\"row\">
                <div class=\"col-lg-3 col-md-12 col-sm-12 col-xs-12\">
                    <div class=\"card\">
                        <div class=\"body\">
                            <div class=\"w_summary\">

                                <div class=\"s_detail\">
                                    <h2 class=\"font700 mb-0\">";
            // line 57
            echo twig_escape_filter($this->env, (isset($context["TotalJeuneGroupe"]) || array_key_exists("TotalJeuneGroupe", $context) ? $context["TotalJeuneGroupe"] : (function () { throw new RuntimeError('Variable "TotalJeuneGroupe" does not exist.', 57, $this->source); })()), "html", null, true);
            echo "</h2>
                                    <span><i class=\"fa fa-level-up text-success\"></i> Total Jeune</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class=\"col-lg-3 col-md-12 col-sm-12 col-xs-12\">
                    <div class=\"card\">
                        <div class=\"body\">
                            <div class=\"w_summary\">
                          
                                <div class=\"s_detail\">
                                    <h2 class=\"font700 mb-0\" id=\"\">";
            // line 70
            echo twig_escape_filter($this->env, (isset($context["TotalResponsable"]) || array_key_exists("TotalResponsable", $context) ? $context["TotalResponsable"] : (function () { throw new RuntimeError('Variable "TotalResponsable" does not exist.', 70, $this->source); })()), "html", null, true);
            echo "</h2>
                                    <span> <i class=\"fa fa-level-up text-success\"></i> Total chefs</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class=\"col-lg-3 col-md-12 col-sm-12 col-xs-12\">
                    <div class=\"card\">
                        <div class=\"body\">
                            <div class=\"w_summary\">
                             
                                <div class=\"s_detail\">
                                    <h2 class=\"font700 mb-0\">";
            // line 83
            echo twig_escape_filter($this->env, (isset($context["TotalJeuneGarcon"]) || array_key_exists("TotalJeuneGarcon", $context) ? $context["TotalJeuneGarcon"] : (function () { throw new RuntimeError('Variable "TotalJeuneGarcon" does not exist.', 83, $this->source); })()), "html", null, true);
            echo "</h2>
                                    <span><i class=\"fa fa-level-up text-success\"></i>Total Jeune Garcon</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class=\"col-lg-3 col-md-12 col-sm-12 col-xs-12\">
                    <div class=\"card\">
                        <div class=\"body\">
                            <div class=\"w_summary\">
                               
                                <div class=\"s_detail\">
                                    <h2 class=\"font700 mb-0\">";
            // line 96
            echo twig_escape_filter($this->env, (isset($context["TotalJeuneFille"]) || array_key_exists("TotalJeuneFille", $context) ? $context["TotalJeuneFille"] : (function () { throw new RuntimeError('Variable "TotalJeuneFille" does not exist.', 96, $this->source); })()), "html", null, true);
            echo "</h2>
                                    <span><i class=\"fa fa-level-up text-success\"></i>Total Jeune Fille</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class=\"row\">
                <div class=\"col-lg-3 col-md-12 col-sm-12 col-xs-12 col-12\">
                    <div class=\"card bg-info\">
                    <div class=\"body\">
                        <div class=\"w_summary\" >

                            <div class=\"s_detail\">
                                <h2 class=\"font700 mb-0\">";
            // line 112
            echo twig_escape_filter($this->env, (isset($context["TotalJeuneCotiseGroupe"]) || array_key_exists("TotalJeuneCotiseGroupe", $context) ? $context["TotalJeuneCotiseGroupe"] : (function () { throw new RuntimeError('Variable "TotalJeuneCotiseGroupe" does not exist.', 112, $this->source); })()), "html", null, true);
            echo "</h2>
                                <span><i class=\"fa fa-level-up text-success\"></i> Total Jeunes Cotisés</span>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
                <div class=\"col-lg-3 col-md-12 col-sm-12 col-xs-12 col-12\">
                    <div class=\"card bg-info\">
                    <div class=\"body\">
                        <div class=\"w_summary\" >

                            <div class=\"s_detail\">
                                <h2 class=\"font700 mb-0\" id=\"\">";
            // line 125
            echo twig_escape_filter($this->env, (isset($context["TotalChefCotiseGroupe"]) || array_key_exists("TotalChefCotiseGroupe", $context) ? $context["TotalChefCotiseGroupe"] : (function () { throw new RuntimeError('Variable "TotalChefCotiseGroupe" does not exist.', 125, $this->source); })()), "html", null, true);
            echo "</h2>
                                <span><i class=\"fa fa-level-up text-success\"></i> Total Chefs Cotisés</span>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>

            </div>

        ";
        }
        // line 136
        echo "
        ";
        // line 137
        if ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("ROLE_SUPERADMIN")) {
            // line 138
            echo "            <div class=\"row\">
                <div class=\"col-md-6\"><div class=\"card\">
                        <div class=\"body top_counter\">
                            <div class=\"icon bg-warning text-white\"><i class=\"fa fa-building\"></i> </div>
                            <div class=\"content\">
                                <span>Total Jeune</span>
                                <h5 class=\"number mb-0\">";
            // line 144
            echo twig_escape_filter($this->env, (isset($context["NbreTotalJeuneDistrict"]) || array_key_exists("NbreTotalJeuneDistrict", $context) ? $context["NbreTotalJeuneDistrict"] : (function () { throw new RuntimeError('Variable "NbreTotalJeuneDistrict" does not exist.', 144, $this->source); })()), "html", null, true);
            echo "</h5>

                            </div>
                        </div>
                    </div></div>
                <div class=\"col-md-6\"><div class=\"card\">
                        <div class=\"body top_counter\">
                            <div class=\"icon bg-warning text-white\"><i class=\"fa fa-building\"></i> </div>
                            <div class=\"content\">
                                <span>Total Chef</span>
                                <h5 class=\"number mb-0\">";
            // line 154
            echo twig_escape_filter($this->env, (isset($context["TotalChefDistrict"]) || array_key_exists("TotalChefDistrict", $context) ? $context["TotalChefDistrict"] : (function () { throw new RuntimeError('Variable "TotalChefDistrict" does not exist.', 154, $this->source); })()), "html", null, true);
            echo "</h5>
                            </div>
                        </div>
                    </div></div>
            </div>


            <h4>Jeune par groupe</h4>
            <hr>
        <div class=\"row\">
            ";
            // line 164
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["TotalJeuneByGroupe"]) || array_key_exists("TotalJeuneByGroupe", $context) ? $context["TotalJeuneByGroupe"] : (function () { throw new RuntimeError('Variable "TotalJeuneByGroupe" does not exist.', 164, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["groupe"]) {
                // line 165
                echo "
                <div class=\"col-md-3\"><div class=\"card\">
                        <div class=\"body top_counter\">
                            <div class=\"icon bg-warning text-white\"><i class=\"fa fa-building\"></i> </div>
                            <div class=\"content\">
                                <span>";
                // line 170
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["groupe"], "Nom", [], "array", false, false, false, 170), "html", null, true);
                echo "</span>
                                <h5 class=\"number mb-0\">";
                // line 171
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["groupe"], "NbreJeune", [], "array", false, false, false, 171), "html", null, true);
                echo " jeunes</h5>
                            </div>
                        </div>

                    </div>

                </div>


            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['groupe'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 181
            echo "        </div>

            <h4>Jeune par branche</h4>
            <hr>
            <div class=\"row\">
                ";
            // line 186
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["TotalJeuneByGroupe"]) || array_key_exists("TotalJeuneByGroupe", $context) ? $context["TotalJeuneByGroupe"] : (function () { throw new RuntimeError('Variable "TotalJeuneByGroupe" does not exist.', 186, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["groupe"]) {
                // line 187
                echo "
                    <div class=\"col-md-3\"><div class=\"card\">
                            <div class=\"body top_counter\">
                                <div class=\"icon bg-warning text-white\"><i class=\"fa fa-building\"></i> </div>
                                <div class=\"content\">
                                    <span>";
                // line 192
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["groupe"], "Nom", [], "array", false, false, false, 192), "html", null, true);
                echo "</span>
                                    <h5 class=\"number mb-0\">";
                // line 193
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["groupe"], "NbreJeune", [], "array", false, false, false, 193), "html", null, true);
                echo " jeunes</h5>
                                </div>
                            </div>

                        </div>

                    </div>


                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['groupe'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 203
            echo "            </div>
   



        ";
        }
        // line 209
        echo "        <div class=\"row\">
            <div class=\"col-lg-6 col-md-12 col-sm-12 col-sx-12 col-12\">
                <div class=\"card\">
                    <div class=\"body\">
                        <canvas id=\"myChart\" width=\"400\" height=\"400\"></canvas>
                    </div>
                </div>
            </div>
            <div class=\"col-lg-6 col-md-12 col-sm-12 col-sx-12 col-12\">
                <div class=\"card\">
                    <div class=\"body\">
                        <p align=\"text-center\">Nombre de cotisés</p>
                        <canvas id=\"cotisation\" width=\"400\" height=\"400\"></canvas>
                    </div>
                </div>
            </div>
        </div>































        </div>

    </div>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 262
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 263
        echo "

    <script src=\"https://cdn.jsdelivr.net/npm/chart.js\"></script>
    <script>
        
        var louv = document.getElementById(\"louv\").value;
        var eclaireur = document.getElementById(\"ecl\").value;
        var cheminot = document.getElementById(\"chem\").value;
        var routier = document.getElementById(\"rout\").value;
        var respo = document.getElementById(\"respo\").value;
       // var respo = 0;
        var louvc = document.getElementById(\"louvc\").value;
        var eclaic = document.getElementById(\"eclaic\").value;
        var chemc = document.getElementById(\"chemc\").value;
        var routc = document.getElementById(\"routc\").value;
        var chefcotise = document.getElementById(\"chefcotise\").value;
        
        console.log(louv);
        var ctx = document.getElementById('myChart').getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Louveteaux', 'Eclaireurs', 'Cheminots', 'Routiers','Adultes'],
                datasets: [{
                    label: 'Nombre de scouts',
                    data: [louv, eclaireur, cheminot, routier,respo],
                    backgroundColor: [
                        'yellow',
                        'green',
                        'orange',
                        'red',
                        'blue'

                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        })


        var ctxCotisation = document.getElementById('cotisation').getContext('2d');
        var myChartCotisation = new Chart(ctxCotisation, {
            type: 'pie',
            data: {
                labels: ['Louveteaux', 'Eclaireurs', 'Cheminots', 'Routiers','Adultes'],
                datasets: [{
                    label: 'Nombre de cotisés',
                    data: [louvc, eclaic, chemc, routc,chefcotise],
                    backgroundColor: [
                        'yellow',
                        'green',
                        'orange',
                        'red',
                        'blue'

                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)'
                    ],
                    borderWidth: 1,
                    title:'dddd'
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }

            }
        });
    </script>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "connexion/Dashboard.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  483 => 263,  473 => 262,  411 => 209,  403 => 203,  387 => 193,  383 => 192,  376 => 187,  372 => 186,  365 => 181,  349 => 171,  345 => 170,  338 => 165,  334 => 164,  321 => 154,  308 => 144,  300 => 138,  298 => 137,  295 => 136,  281 => 125,  265 => 112,  246 => 96,  230 => 83,  214 => 70,  198 => 57,  188 => 49,  186 => 48,  174 => 39,  161 => 29,  157 => 28,  153 => 27,  149 => 26,  145 => 25,  141 => 24,  137 => 23,  133 => 22,  129 => 21,  125 => 20,  120 => 17,  110 => 16,  91 => 14,  79 => 12,  74 => 10,  71 => 9,  61 => 8,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}






{% block stylesheets %}

    <link rel=\"stylesheet\" href=\"{{ asset('assets/vendor/jquery-datatable/dataTables.bootstrap4.min.css') }}\"/>

    <link rel=\"stylesheet\" href=\"{{ asset(\"c3n/c3.css\") }}\"/>
{% endblock %}
{% block titre %} Tableau de bord {% endblock %}

{% block body %}



    <input type=\"hidden\" id=\"louvc\" value=\"{{ nbreCotiseLouveteau }}\">
    <input type=\"hidden\" id=\"eclaic\" value=\"{{ nbreCotiseEclaireur }}\">
    <input type=\"hidden\" id=\"chemc\" value=\"{{ nbreCotiseCheminot }}\">
    <input type=\"hidden\" id=\"routc\" value=\"{{ nbreCotiseRoutier }}\">
    <input type=\"hidden\" id=\"louv\" value=\"{{ TotalLouveteau }}\"/>
    <input type=\"hidden\" id=\"ecl\" value=\"{{ TotalEclaireur }}\">
    <input type=\"hidden\" id=\"chem\" value=\"{{ TotalCheminot }}\">
    <input type=\"hidden\" id=\"rout\" value=\"{{ TotalRoutier }}\">
    <input type=\"hidden\" id=\"chefcotise\" value=\"{{TotalChefCotiseGroupe }}\"/>
    <input type=\"hidden\" id=\"respo\" value=\"{{TotalResponsable}}\"/>

    <div class=\"block-header\">
        <div class=\"row clearfix\">
            <div class=\"col-md-6 col-sm-12\">
                <h1>Tableau de bord</h1>


            </div>
            <div class=\"col-md-6 col-sm-12 text-right hidden-xs\">
                <h1 style=\"color=red;\">{{ Annee }}</h1>

            </div>
        </div>
    </div>

    <div class=\"container-fluid\">


        {% if is_granted('ROLE_CG') %}

            <div class=\"row\">
                <div class=\"col-lg-3 col-md-12 col-sm-12 col-xs-12\">
                    <div class=\"card\">
                        <div class=\"body\">
                            <div class=\"w_summary\">

                                <div class=\"s_detail\">
                                    <h2 class=\"font700 mb-0\">{{ TotalJeuneGroupe }}</h2>
                                    <span><i class=\"fa fa-level-up text-success\"></i> Total Jeune</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class=\"col-lg-3 col-md-12 col-sm-12 col-xs-12\">
                    <div class=\"card\">
                        <div class=\"body\">
                            <div class=\"w_summary\">
                          
                                <div class=\"s_detail\">
                                    <h2 class=\"font700 mb-0\" id=\"\">{{ TotalResponsable }}</h2>
                                    <span> <i class=\"fa fa-level-up text-success\"></i> Total chefs</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class=\"col-lg-3 col-md-12 col-sm-12 col-xs-12\">
                    <div class=\"card\">
                        <div class=\"body\">
                            <div class=\"w_summary\">
                             
                                <div class=\"s_detail\">
                                    <h2 class=\"font700 mb-0\">{{ TotalJeuneGarcon }}</h2>
                                    <span><i class=\"fa fa-level-up text-success\"></i>Total Jeune Garcon</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class=\"col-lg-3 col-md-12 col-sm-12 col-xs-12\">
                    <div class=\"card\">
                        <div class=\"body\">
                            <div class=\"w_summary\">
                               
                                <div class=\"s_detail\">
                                    <h2 class=\"font700 mb-0\">{{ TotalJeuneFille }}</h2>
                                    <span><i class=\"fa fa-level-up text-success\"></i>Total Jeune Fille</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class=\"row\">
                <div class=\"col-lg-3 col-md-12 col-sm-12 col-xs-12 col-12\">
                    <div class=\"card bg-info\">
                    <div class=\"body\">
                        <div class=\"w_summary\" >

                            <div class=\"s_detail\">
                                <h2 class=\"font700 mb-0\">{{ TotalJeuneCotiseGroupe }}</h2>
                                <span><i class=\"fa fa-level-up text-success\"></i> Total Jeunes Cotisés</span>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
                <div class=\"col-lg-3 col-md-12 col-sm-12 col-xs-12 col-12\">
                    <div class=\"card bg-info\">
                    <div class=\"body\">
                        <div class=\"w_summary\" >

                            <div class=\"s_detail\">
                                <h2 class=\"font700 mb-0\" id=\"\">{{ TotalChefCotiseGroupe }}</h2>
                                <span><i class=\"fa fa-level-up text-success\"></i> Total Chefs Cotisés</span>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>

            </div>

        {% endif %}

        {% if is_granted('ROLE_SUPERADMIN') %}
            <div class=\"row\">
                <div class=\"col-md-6\"><div class=\"card\">
                        <div class=\"body top_counter\">
                            <div class=\"icon bg-warning text-white\"><i class=\"fa fa-building\"></i> </div>
                            <div class=\"content\">
                                <span>Total Jeune</span>
                                <h5 class=\"number mb-0\">{{ NbreTotalJeuneDistrict }}</h5>

                            </div>
                        </div>
                    </div></div>
                <div class=\"col-md-6\"><div class=\"card\">
                        <div class=\"body top_counter\">
                            <div class=\"icon bg-warning text-white\"><i class=\"fa fa-building\"></i> </div>
                            <div class=\"content\">
                                <span>Total Chef</span>
                                <h5 class=\"number mb-0\">{{ TotalChefDistrict }}</h5>
                            </div>
                        </div>
                    </div></div>
            </div>


            <h4>Jeune par groupe</h4>
            <hr>
        <div class=\"row\">
            {% for groupe in TotalJeuneByGroupe %}

                <div class=\"col-md-3\"><div class=\"card\">
                        <div class=\"body top_counter\">
                            <div class=\"icon bg-warning text-white\"><i class=\"fa fa-building\"></i> </div>
                            <div class=\"content\">
                                <span>{{ groupe[\"Nom\"] }}</span>
                                <h5 class=\"number mb-0\">{{ groupe[\"NbreJeune\"] }} jeunes</h5>
                            </div>
                        </div>

                    </div>

                </div>


            {% endfor %}
        </div>

            <h4>Jeune par branche</h4>
            <hr>
            <div class=\"row\">
                {% for groupe in TotalJeuneByGroupe %}

                    <div class=\"col-md-3\"><div class=\"card\">
                            <div class=\"body top_counter\">
                                <div class=\"icon bg-warning text-white\"><i class=\"fa fa-building\"></i> </div>
                                <div class=\"content\">
                                    <span>{{ groupe[\"Nom\"] }}</span>
                                    <h5 class=\"number mb-0\">{{ groupe[\"NbreJeune\"] }} jeunes</h5>
                                </div>
                            </div>

                        </div>

                    </div>


                {% endfor %}
            </div>
   



        {% endif %}
        <div class=\"row\">
            <div class=\"col-lg-6 col-md-12 col-sm-12 col-sx-12 col-12\">
                <div class=\"card\">
                    <div class=\"body\">
                        <canvas id=\"myChart\" width=\"400\" height=\"400\"></canvas>
                    </div>
                </div>
            </div>
            <div class=\"col-lg-6 col-md-12 col-sm-12 col-sx-12 col-12\">
                <div class=\"card\">
                    <div class=\"body\">
                        <p align=\"text-center\">Nombre de cotisés</p>
                        <canvas id=\"cotisation\" width=\"400\" height=\"400\"></canvas>
                    </div>
                </div>
            </div>
        </div>































        </div>

    </div>

{% endblock %}
{% block javascripts %}


    <script src=\"https://cdn.jsdelivr.net/npm/chart.js\"></script>
    <script>
        
        var louv = document.getElementById(\"louv\").value;
        var eclaireur = document.getElementById(\"ecl\").value;
        var cheminot = document.getElementById(\"chem\").value;
        var routier = document.getElementById(\"rout\").value;
        var respo = document.getElementById(\"respo\").value;
       // var respo = 0;
        var louvc = document.getElementById(\"louvc\").value;
        var eclaic = document.getElementById(\"eclaic\").value;
        var chemc = document.getElementById(\"chemc\").value;
        var routc = document.getElementById(\"routc\").value;
        var chefcotise = document.getElementById(\"chefcotise\").value;
        
        console.log(louv);
        var ctx = document.getElementById('myChart').getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Louveteaux', 'Eclaireurs', 'Cheminots', 'Routiers','Adultes'],
                datasets: [{
                    label: 'Nombre de scouts',
                    data: [louv, eclaireur, cheminot, routier,respo],
                    backgroundColor: [
                        'yellow',
                        'green',
                        'orange',
                        'red',
                        'blue'

                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        })


        var ctxCotisation = document.getElementById('cotisation').getContext('2d');
        var myChartCotisation = new Chart(ctxCotisation, {
            type: 'pie',
            data: {
                labels: ['Louveteaux', 'Eclaireurs', 'Cheminots', 'Routiers','Adultes'],
                datasets: [{
                    label: 'Nombre de cotisés',
                    data: [louvc, eclaic, chemc, routc,chefcotise],
                    backgroundColor: [
                        'yellow',
                        'green',
                        'orange',
                        'red',
                        'blue'

                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)'
                    ],
                    borderWidth: 1,
                    title:'dddd'
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }

            }
        });
    </script>

{% endblock %}", "connexion/Dashboard.html.twig", "D:\\CODES SOURCES\\SYMFONY\\GestiScoutWeb\\templates\\connexion\\Dashboard.html.twig");
    }
}

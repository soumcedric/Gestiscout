<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* activite/ListActivite.html.twig */
class __TwigTemplate_d29c917544acaa6dd1142bcae67941890843801a180bd99006bc2e4494cb44ee extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'titre' => [$this, 'block_titre'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "activite/ListActivite.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "activite/ListActivite.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "activite/ListActivite.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_titre($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "titre"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "titre"));

        echo "LISTE DES ACTIVITES ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 4
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 5
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/sweetalert/sweetalert.css"), "html", null, true);
        echo "\"/>
";
        // line 10
        echo "<style>
    .example-wrapper { margin: 1em auto; max-width: 800px; width: 95%; font: 18px/1.5 sans-serif; }
    .example-wrapper code { background: #F5F5F5; padding: 2px 6px; }
    .bd-example-modal-lg .modal-dialog{
        display: table;
        position: relative;
        margin: 0 auto;
        top: calc(50% - 24px);
    }

    .bd-example-modal-lg .modal-dialog .modal-content{
        background-color: transparent;
        border: none;
    }
</style>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 27
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 28
        echo "
    <div class=\"block-header\">
        <div class=\"row clearfix\">
            <div class=\"col-md-6 col-sm-12\">
";
        // line 40
        echo "            </div>
            <div class=\"col-md-6 col-sm-12 text-right hidden-xs\">
";
        // line 43
        echo "            </div>
        </div>
    </div>
       <div class=\"container-fluid\">
            <div class=\"row clearfix\">
                <div class=\"col-lg-12\">
                <div class=\"col-lg-12\">
        <div class=\"card\">
            <div class=\"header\">
                <h2 class=\"text-center\">Liste des activités</h2>
            </div>
            <div class=\"body\">
                <div class=\"table-responsive\">
                    <table class=\"table\" id=\"tbactivites\">
                        <thead class=\"thead-light\">
                        <tr>
                            <th>ID</th>
                            <th>Libelle</th>
                            <th>Groupe</th>
                            <th>Branche</th>
                            <th>Date Debut</th>
                            <th>Date Fin</th>
                            <th>Prix</th>
                            <th>Participant</th>
                            <th>ACTION</th>
                        </tr>
                        </thead>
                        <tbody>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
             </div>
   </div>
       </div>












    <div class=\"modal fade\" id=\"modalmodif\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"exampleModalLabel\" aria-hidden=\"true\">
                                <div class=\"modal-dialog\" role=\"document\">
                                    <div class=\"modal-content\">
                                        <div class=\"modal-header\">
                                            <h5 class=\"modal-title\" id=\"exampleModalLabel\">Modifications du responsable</h5>
                                            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
                                                <span aria-hidden=\"true\">&times;</span>
                                            </button>
                                        </div>
                                        <input type=\"hidden\" id=\"respoId\">
                                        <div class=\"modal-body\">
                                            <div class=\"row\">
                                                <div class=\"col-lg-6\">
                                                    <form id=\"basic-form\" method=\"post\" novalidate>
                                                        <div class=\"form-group\">
                                                            <label>Nom</label>
                                                            <input type=\"text\" class=\"form-control\" required id=\"Nom\">
                                                        </div>
                                                        <div class=\"form-group\">
                                                            <label>Prénoms</label>
                                                            <input type=\"text\" class=\"form-control\" required id=\"prenoms\">
                                                        </div>
                                                        <div class=\"form-group\">
                                                            <label>Date de naissance</label>
                                                            <input type=\"date\" class=\"form-control\" required id=\"dob\">
                                                        </div>
                                                        <div class=\"form-group\">
                                                            <label>Fonction</label>
                                                            <select id=\"fonction\" class=\"form-control\"></select>
                                                        </div>
                                        
                                        
                                        
                                                        <br>
                                        
                                                    </form>
                                                </div>
                                                <div class=\"col-lg-6\">
                                                    <form id=\"basic-form\" method=\"post\" novalidate>
                                                        <div class=\"form-group\">
                                                            <label>Lieu d'habitation</label>
                                                            <input type=\"text\" class=\"form-control\" required id=\"habitation\">
                                                        </div>
                                                        <div class=\"form-group\">
                                                            <label>Occupation</label>
                                                            <input type=\"text\" class=\"form-control\" required id=\"occupation\">
                                                        </div>
                                                        <div class=\"form-group\">
                                                            <label>Téléphone</label>
                                                            <input type=\"text\" class=\"form-control\" required id=\"telephone\">
                                                        </div>
                                        
";
        // line 150
        echo "                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <div class=\"modal-footer\">
                                            <button type=\"button\" class=\"btn btn-round btn-default\" data-dismiss=\"modal\">Annuler</button>
                                            <button type=\"button\" id=\"saveModif\" class=\"btn btn-round btn-primary\">Enregistrer</button>
                                        </div>
                                    </div>
                                </div>
                            </div>


    <div class=\"modal fade\" id=\"modalcompte\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"exampleModalLabel\" aria-hidden=\"true\">
        <div class=\"modal-dialog\" role=\"document\">
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <h5 class=\"modal-title\" id=\"exampleModalLabel\">Modifications du responsable</h5>
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
                        <span aria-hidden=\"true\">&times;</span>
                    </button>
                </div>
                <input type=\"hidden\" id=\"respoId\">
                <div class=\"modal-body\">
                    <div class=\"row\">
                        <div class=\"col-lg-6\">
                            <form id=\"basic-form\" method=\"post\" novalidate>
                                <div class=\"form-group\">
                                    <label>Nom Utilisateur</label>
                                    <input type=\"text\" class=\"form-control\" required id=\"Username\">
                                </div>
                                <div class=\"form-group\">
                                    <label>Mot de passe</label>
                                    <input type=\"password\" class=\"form-control\" required id=\"password\">
                                </div>

                                                     <br>

                            </form>
                        </div>
                        <div class=\"col-lg-6\">
                            <form id=\"basic-form\" method=\"post\" novalidate>
                                <div class=\"form-group\">
                                    <label>Profil</label>
                                    <select class=\"form-control\" id=\"role\">
                                        <option value=\"0\">---choisir un profil---</option>
                                        <option value=\"ROLE_SUPERADMIN\">Super Administrateur</option>
                                        <option value=\"ROLE_ADMIN\">Administrateur</option>
                                        <option value=\"ROLE_CONSULTANT\">Consultant</option>
                                    </select>
                                </div>
                                <div class=\"form-group\">
                                    <label>Confirmer mot de passe</label>
                                    <input type=\"password\" class=\"form-control\" required id=\"confirmpass\">
                                </div>


                            </form>
                        </div>
                    </div>
                </div>
                <div class=\"modal-footer\">
                    <button type=\"button\" class=\"btn btn-round btn-default\" data-dismiss=\"modal\">Annuler</button>
                    <button type=\"button\" id=\"saveuser\" class=\"btn btn-round btn-primary\">Enregistrer</button>
                </div>
            </div>
        </div>
    </div>






    <div class=\"modal modal_load fade bd-example-modal-lg\" data-backdrop=\"static\" data-keyboard=\"false\" tabindex=\"-1\">
        <div class=\"modal-dialog modal-sm\">
            <div class=\"modal-content\" style=\"width: 48px\">
                <span class=\"fa fa-spinner fa-spin fa-3x\"></span>
            </div>
        </div>
    </div>





";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 237
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 238
        echo "
    <script src=\"";
        // line 239
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/jquery-datatable/jquery.dataTables.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 240
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/sweetalert/sweetalert.min.js"), "html", null, true);
        echo " \"></script>
    <script src=\"";
        // line 241
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/bundles/datatablescripts.bundle.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 242
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/jquery-datatable/buttons/dataTables.buttons.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 243
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/jquery-datatable/buttons/buttons.bootstrap4.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 244
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/jquery-datatable/buttons/buttons.colVis.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 245
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/jquery-datatable/buttons/buttons.html5.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 246
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/jquery-datatable/buttons/buttons.print.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js\"></script>
    <script>
        \$(document).ready(function(){
            debugger
            var table = \$(\"#tbactivites\").DataTable({
                language: {
                    processing: \"Traitement en cours...\",
                    search: \"Rechercher&nbsp;:\",
                    lengthMenu: \"Afficher _MENU_ &eacute;l&eacute;ments\",
                    info: \"Affichage de l'&eacute;lement _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments\",
                    infoEmpty: \"Affichage de l'&eacute;lement 0 &agrave; 0 sur 0 &eacute;l&eacute;ments\",
                    infoFiltered: \"(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)\",
                    infoPostFix: \"\",
                    loadingRecords: \"Chargement en cours...\",
                    zeroRecords: \"Aucun &eacute;l&eacute;ment &agrave; afficher\",
                    emptyTable: \"Aucune donnée disponible dans le tableau\",
                    paginate: {
                        first: \"Premier\",
                        previous: \"Pr&eacute;c&eacute;dent\",
                        next: \"Suivant\",
                        last: \"Dernier\"
                    }
                },
                columns: [
                    { \"data\": \"ID\" },
                    { \"data\": \"LIBELLE\" },
                    { \"data\": \"GROUPE\" },
                    { \"data\": \"BRANCHE\" },
                    { \"data\": \"DEBUT\" },
                    { \"data\": \"FIN\" },
                    { \"data\": \"PRIX\" },
                    { \"data\": \"NBRE\" },
                    { \"data\": \"ACTION\" }
                ],
                columnDefs: [
                    {
                        targets: 0,
                        visible: false
                    }],
                dom:'Bfrtip',
                buttons: [

                    {
                        extend: 'print',
                        text:'Imprimer',
                        messageTop: function () {
                            return 'Liste des responsables'
                        },
                        messageBottom: null
                    },
                    {
                        extend: 'pdfHtml5',
                        orientation: 'portrait',
                        pageSize: 'LEGAL',
                        title:'Liste des Responsables',
                        exportOptions:{
                            columns:[0,1,2,3,4]
                        },
                        customize: function(doc) {
                            //doc.content[1].margin = [ 100, 0, 100, 0 ] //left, top, right, bottom
                        }
                    }

                ],
                data: [],
                rowCallback: function (row, data) { },
                filter: true,
                info: true,
                ordering: false,
                processing: false,
                retrieve: true
            });
         

         \$.ajax({
             type:\"GET\",
             url:\"";
        // line 324
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("ListActivites");
        echo "\",
             success:function(res){
                 debugger
                 if (res.ok == true) {
                     let liste = JSON.parse(res.data);
                     \$.each(liste,function(i,n){
                         debugger
                         //var date = n.date_debut.replace('0','');
                        var newDate = convertDate(n.date_debut);
                        var newDateFin = convertDate(n.date_fin);
                         table.rows.add([{
                    \"ID\" :n.id,
                   \"LIBELLE\":n.nomactivite,
                    \"GROUPE\" :n.nomgroupe,
                    \"BRANCHE\" :n.nombranche,
                     \"DEBUT\" :newDate,
                     \"FIN\" :newDateFin,
                      \"PRIX\" :n.prix+\" F CFA\",
                       \"NBRE\" :n.nbre_participant,
                    \"ACTION\" :\"<input type='button' id='details' class='btn btn-success' value='voir details' /><input type='button' id='programme' value='Programme' class='btn btn-success'/>\"
                         }]).draw();
                     })
                 }
             }
         })

     function convertDate(dateToConvert){
         var dateAr = dateToConvert.split('-');
       
        var newDate =  dateAr[2].substring(0,2)  + '-' + dateAr[1]+ '-' + dateAr[0];
        return newDate;
     }
        \$(\"#tbactivites\").on('click','tbody > tr > td > input[id=programme]',function (){
            debugger
            var row = table.row( \$(this).parents('tr') ).data();
            var ID = row.ID;
            \$.ajax({
                type:\"GET\",
                url:\"";
        // line 362
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("redirectToProgramme");
        echo "\",
                data:{\"value\":ID},
                success:function(res){
                    debugger
                   window.location=res.url;

                },
                error:function(res){

                }

            });
        });


        });
    </script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "activite/ListActivite.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  503 => 362,  462 => 324,  381 => 246,  377 => 245,  373 => 244,  369 => 243,  365 => 242,  361 => 241,  357 => 240,  353 => 239,  350 => 238,  340 => 237,  244 => 150,  140 => 43,  136 => 40,  130 => 28,  120 => 27,  95 => 10,  90 => 5,  80 => 4,  61 => 3,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block titre %}LISTE DES ACTIVITES {% endblock %}
{% block stylesheets %}
    <link rel=\"stylesheet\" href=\"{{ asset(\"assets/vendor/sweetalert/sweetalert.css\") }}\"/>
{#    <link rel=\"stylesheet\" href=\"{{ asset(\"assets/vendor/jquery-datatable/dataTables.bootstrap4.min.css\") }}\">#}
{#    <link rel=\"stylesheet\" href=\"{{ asset(\"assets/vendor/jquery-datatable/fixedeader/dataTables.fixedcolumns.bootstrap4.min.css\") }}\">#}
{#    <link rel=\"stylesheet\" href=\"{{ asset(\"assets/vendor/jquery-datatable/fixedeader/dataTables.fixedheader.bootstrap4.min.css\") }}\">#}
{#{% endblock %}#}
<style>
    .example-wrapper { margin: 1em auto; max-width: 800px; width: 95%; font: 18px/1.5 sans-serif; }
    .example-wrapper code { background: #F5F5F5; padding: 2px 6px; }
    .bd-example-modal-lg .modal-dialog{
        display: table;
        position: relative;
        margin: 0 auto;
        top: calc(50% - 24px);
    }

    .bd-example-modal-lg .modal-dialog .modal-content{
        background-color: transparent;
        border: none;
    }
</style>
{% endblock %}

{% block body %}

    <div class=\"block-header\">
        <div class=\"row clearfix\">
            <div class=\"col-md-6 col-sm-12\">
{#                <h1>Color Table</h1>#}
{#                <nav aria-label=\"breadcrumb\">#}
{#                    <ol class=\"breadcrumb\">#}
{#                        <li class=\"breadcrumb-item\"><a href=\"#\"><i class=\"fa fa-cube\"></i></a></li>#}
{#                        <li class=\"breadcrumb-item\"><a href=\"#\">Liste des responsables</a></li>#}
{#                        <li class=\"breadcrumb-item active\" aria-current=\"page\">Color Table</li>#}
{#                    </ol>#}
{#                </nav>#}
            </div>
            <div class=\"col-md-6 col-sm-12 text-right hidden-xs\">
{#                <a href=\"{{ path(\"AjouterRespoView\") }}\" class=\"btn btn-sm btn-primary\" title=\"\">Ajouter un responsable</a>#}
            </div>
        </div>
    </div>
       <div class=\"container-fluid\">
            <div class=\"row clearfix\">
                <div class=\"col-lg-12\">
                <div class=\"col-lg-12\">
        <div class=\"card\">
            <div class=\"header\">
                <h2 class=\"text-center\">Liste des activités</h2>
            </div>
            <div class=\"body\">
                <div class=\"table-responsive\">
                    <table class=\"table\" id=\"tbactivites\">
                        <thead class=\"thead-light\">
                        <tr>
                            <th>ID</th>
                            <th>Libelle</th>
                            <th>Groupe</th>
                            <th>Branche</th>
                            <th>Date Debut</th>
                            <th>Date Fin</th>
                            <th>Prix</th>
                            <th>Participant</th>
                            <th>ACTION</th>
                        </tr>
                        </thead>
                        <tbody>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
             </div>
   </div>
       </div>












    <div class=\"modal fade\" id=\"modalmodif\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"exampleModalLabel\" aria-hidden=\"true\">
                                <div class=\"modal-dialog\" role=\"document\">
                                    <div class=\"modal-content\">
                                        <div class=\"modal-header\">
                                            <h5 class=\"modal-title\" id=\"exampleModalLabel\">Modifications du responsable</h5>
                                            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
                                                <span aria-hidden=\"true\">&times;</span>
                                            </button>
                                        </div>
                                        <input type=\"hidden\" id=\"respoId\">
                                        <div class=\"modal-body\">
                                            <div class=\"row\">
                                                <div class=\"col-lg-6\">
                                                    <form id=\"basic-form\" method=\"post\" novalidate>
                                                        <div class=\"form-group\">
                                                            <label>Nom</label>
                                                            <input type=\"text\" class=\"form-control\" required id=\"Nom\">
                                                        </div>
                                                        <div class=\"form-group\">
                                                            <label>Prénoms</label>
                                                            <input type=\"text\" class=\"form-control\" required id=\"prenoms\">
                                                        </div>
                                                        <div class=\"form-group\">
                                                            <label>Date de naissance</label>
                                                            <input type=\"date\" class=\"form-control\" required id=\"dob\">
                                                        </div>
                                                        <div class=\"form-group\">
                                                            <label>Fonction</label>
                                                            <select id=\"fonction\" class=\"form-control\"></select>
                                                        </div>
                                        
                                        
                                        
                                                        <br>
                                        
                                                    </form>
                                                </div>
                                                <div class=\"col-lg-6\">
                                                    <form id=\"basic-form\" method=\"post\" novalidate>
                                                        <div class=\"form-group\">
                                                            <label>Lieu d'habitation</label>
                                                            <input type=\"text\" class=\"form-control\" required id=\"habitation\">
                                                        </div>
                                                        <div class=\"form-group\">
                                                            <label>Occupation</label>
                                                            <input type=\"text\" class=\"form-control\" required id=\"occupation\">
                                                        </div>
                                                        <div class=\"form-group\">
                                                            <label>Téléphone</label>
                                                            <input type=\"text\" class=\"form-control\" required id=\"telephone\">
                                                        </div>
                                        
{#                                                        <div class=\"form-group\">#}
{#                                                            <label>Groupe</label>#}
{#                                                            <select id=\"groupe\" class=\"form-control\"></select>#}
{#                                                        </div>#}
{#                                        #}
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <div class=\"modal-footer\">
                                            <button type=\"button\" class=\"btn btn-round btn-default\" data-dismiss=\"modal\">Annuler</button>
                                            <button type=\"button\" id=\"saveModif\" class=\"btn btn-round btn-primary\">Enregistrer</button>
                                        </div>
                                    </div>
                                </div>
                            </div>


    <div class=\"modal fade\" id=\"modalcompte\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"exampleModalLabel\" aria-hidden=\"true\">
        <div class=\"modal-dialog\" role=\"document\">
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <h5 class=\"modal-title\" id=\"exampleModalLabel\">Modifications du responsable</h5>
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
                        <span aria-hidden=\"true\">&times;</span>
                    </button>
                </div>
                <input type=\"hidden\" id=\"respoId\">
                <div class=\"modal-body\">
                    <div class=\"row\">
                        <div class=\"col-lg-6\">
                            <form id=\"basic-form\" method=\"post\" novalidate>
                                <div class=\"form-group\">
                                    <label>Nom Utilisateur</label>
                                    <input type=\"text\" class=\"form-control\" required id=\"Username\">
                                </div>
                                <div class=\"form-group\">
                                    <label>Mot de passe</label>
                                    <input type=\"password\" class=\"form-control\" required id=\"password\">
                                </div>

                                                     <br>

                            </form>
                        </div>
                        <div class=\"col-lg-6\">
                            <form id=\"basic-form\" method=\"post\" novalidate>
                                <div class=\"form-group\">
                                    <label>Profil</label>
                                    <select class=\"form-control\" id=\"role\">
                                        <option value=\"0\">---choisir un profil---</option>
                                        <option value=\"ROLE_SUPERADMIN\">Super Administrateur</option>
                                        <option value=\"ROLE_ADMIN\">Administrateur</option>
                                        <option value=\"ROLE_CONSULTANT\">Consultant</option>
                                    </select>
                                </div>
                                <div class=\"form-group\">
                                    <label>Confirmer mot de passe</label>
                                    <input type=\"password\" class=\"form-control\" required id=\"confirmpass\">
                                </div>


                            </form>
                        </div>
                    </div>
                </div>
                <div class=\"modal-footer\">
                    <button type=\"button\" class=\"btn btn-round btn-default\" data-dismiss=\"modal\">Annuler</button>
                    <button type=\"button\" id=\"saveuser\" class=\"btn btn-round btn-primary\">Enregistrer</button>
                </div>
            </div>
        </div>
    </div>






    <div class=\"modal modal_load fade bd-example-modal-lg\" data-backdrop=\"static\" data-keyboard=\"false\" tabindex=\"-1\">
        <div class=\"modal-dialog modal-sm\">
            <div class=\"modal-content\" style=\"width: 48px\">
                <span class=\"fa fa-spinner fa-spin fa-3x\"></span>
            </div>
        </div>
    </div>





{% endblock %}
{% block javascripts %}

    <script src=\"{{ asset('assets/vendor/jquery-datatable/jquery.dataTables.min.js') }}\"></script>
    <script src=\"{{ asset(\"assets/vendor/sweetalert/sweetalert.min.js\")}} \"></script>
    <script src=\"{{ asset(\"assets/bundles/datatablescripts.bundle.js\") }}\"></script>
    <script src=\"{{ asset(\"assets/vendor/jquery-datatable/buttons/dataTables.buttons.min.js\") }}\"></script>
    <script src=\"{{ asset(\"assets/vendor/jquery-datatable/buttons/buttons.bootstrap4.min.js\") }}\"></script>
    <script src=\"{{ asset(\"assets/vendor/jquery-datatable/buttons/buttons.colVis.min.js\") }}\"></script>
    <script src=\"{{ asset(\"assets/vendor/jquery-datatable/buttons/buttons.html5.min.js\") }}\"></script>
    <script src=\"{{ asset(\"assets/vendor/jquery-datatable/buttons/buttons.print.min.js\") }}\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js\"></script>
    <script>
        \$(document).ready(function(){
            debugger
            var table = \$(\"#tbactivites\").DataTable({
                language: {
                    processing: \"Traitement en cours...\",
                    search: \"Rechercher&nbsp;:\",
                    lengthMenu: \"Afficher _MENU_ &eacute;l&eacute;ments\",
                    info: \"Affichage de l'&eacute;lement _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments\",
                    infoEmpty: \"Affichage de l'&eacute;lement 0 &agrave; 0 sur 0 &eacute;l&eacute;ments\",
                    infoFiltered: \"(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)\",
                    infoPostFix: \"\",
                    loadingRecords: \"Chargement en cours...\",
                    zeroRecords: \"Aucun &eacute;l&eacute;ment &agrave; afficher\",
                    emptyTable: \"Aucune donnée disponible dans le tableau\",
                    paginate: {
                        first: \"Premier\",
                        previous: \"Pr&eacute;c&eacute;dent\",
                        next: \"Suivant\",
                        last: \"Dernier\"
                    }
                },
                columns: [
                    { \"data\": \"ID\" },
                    { \"data\": \"LIBELLE\" },
                    { \"data\": \"GROUPE\" },
                    { \"data\": \"BRANCHE\" },
                    { \"data\": \"DEBUT\" },
                    { \"data\": \"FIN\" },
                    { \"data\": \"PRIX\" },
                    { \"data\": \"NBRE\" },
                    { \"data\": \"ACTION\" }
                ],
                columnDefs: [
                    {
                        targets: 0,
                        visible: false
                    }],
                dom:'Bfrtip',
                buttons: [

                    {
                        extend: 'print',
                        text:'Imprimer',
                        messageTop: function () {
                            return 'Liste des responsables'
                        },
                        messageBottom: null
                    },
                    {
                        extend: 'pdfHtml5',
                        orientation: 'portrait',
                        pageSize: 'LEGAL',
                        title:'Liste des Responsables',
                        exportOptions:{
                            columns:[0,1,2,3,4]
                        },
                        customize: function(doc) {
                            //doc.content[1].margin = [ 100, 0, 100, 0 ] //left, top, right, bottom
                        }
                    }

                ],
                data: [],
                rowCallback: function (row, data) { },
                filter: true,
                info: true,
                ordering: false,
                processing: false,
                retrieve: true
            });
         

         \$.ajax({
             type:\"GET\",
             url:\"{{path(\"ListActivites\")}}\",
             success:function(res){
                 debugger
                 if (res.ok == true) {
                     let liste = JSON.parse(res.data);
                     \$.each(liste,function(i,n){
                         debugger
                         //var date = n.date_debut.replace('0','');
                        var newDate = convertDate(n.date_debut);
                        var newDateFin = convertDate(n.date_fin);
                         table.rows.add([{
                    \"ID\" :n.id,
                   \"LIBELLE\":n.nomactivite,
                    \"GROUPE\" :n.nomgroupe,
                    \"BRANCHE\" :n.nombranche,
                     \"DEBUT\" :newDate,
                     \"FIN\" :newDateFin,
                      \"PRIX\" :n.prix+\" F CFA\",
                       \"NBRE\" :n.nbre_participant,
                    \"ACTION\" :\"<input type='button' id='details' class='btn btn-success' value='voir details' /><input type='button' id='programme' value='Programme' class='btn btn-success'/>\"
                         }]).draw();
                     })
                 }
             }
         })

     function convertDate(dateToConvert){
         var dateAr = dateToConvert.split('-');
       
        var newDate =  dateAr[2].substring(0,2)  + '-' + dateAr[1]+ '-' + dateAr[0];
        return newDate;
     }
        \$(\"#tbactivites\").on('click','tbody > tr > td > input[id=programme]',function (){
            debugger
            var row = table.row( \$(this).parents('tr') ).data();
            var ID = row.ID;
            \$.ajax({
                type:\"GET\",
                url:\"{{ path(\"redirectToProgramme\") }}\",
                data:{\"value\":ID},
                success:function(res){
                    debugger
                   window.location=res.url;

                },
                error:function(res){

                }

            });
        });


        });
    </script>
{% endblock %}", "activite/ListActivite.html.twig", "D:\\CODES SOURCES\\SYMFONY\\GestiScoutWeb\\templates\\activite\\ListActivite.html.twig");
    }
}

<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* district/ListeJeune.html.twig */
class __TwigTemplate_5e381bd115455dbf8f468c7e911049954253a5578381a0959d869c024e39490e extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'titre' => [$this, 'block_titre'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base_district.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "district/ListeJeune.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "district/ListeJeune.html.twig"));

        $this->parent = $this->loadTemplate("base_district.html.twig", "district/ListeJeune.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_titre($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "titre"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "titre"));

        echo "LISTE DES JEUNES ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 6
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/jquery-datatable/dataTables.bootstrap4.min.css"), "html", null, true);
        echo "\"/>
    ";
        // line 8
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/sweetalert/sweetalert.css"), "html", null, true);
        echo "\"/>

    <link rel=\"stylesheet\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/jquery-datatable/dataTables.bootstrap4.min.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/jquery-datatable/fixedeader/dataTables.fixedcolumns.bootstrap4.min.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/jquery-datatable/fixedeader/dataTables.fixedheader.bootstrap4.min.css"), "html", null, true);
        echo "\">
    <style>
        .bd-example-modal-lg .modal-dialog{
            display: table;
            position: relative;
            margin: 0 auto;
            top: calc(50% - 24px);
        }

        .bd-example-modal-lg .modal-dialog .modal-content{
            background-color: transparent;
            border: none;
        }

    </style>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 28
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 29
        echo "    <style>
        .example-wrapper { margin: 1em auto; max-width: 800px; width: 95%; font: 18px/1.5 sans-serif; }
        .example-wrapper code { background: #F5F5F5; padding: 2px 6px; }
    </style>
    <div class=\"container-fluid\">

        <div class=\"row clearfix\">
            <div class=\"col-md-12\">
                <div class=\"card\">
                    <div class=\"header\">
                        <h2 class=\"text-center\">Recherche des jeunes par critère</h2>
                    </div>
                    <div class=\"body\">
                        <div class=\"row\">
                            <div class=\"col-md-6\">
                                <div class=\"form-group\">
                                    <label>Groupe</label>
                                    <select id=\"groupe\" class=\"form-control\"></select>
                                </div>
                            </div>

                            <div class=\"col-md-6\">

                                <div class=\"form-group\">
                                    <label>Branche</label>
                                    <select id=\"branche\" class=\"form-control\"></select>
                                </div>

                            </div>

                        </div>



                        <div class=\"text-center\">
                            <button type=\"submit\" class=\"btn btn-success\" id=\"valider\">Rechercher</button>
                            <button type=\"submit\" class=\"btn btn-danger\">Annuler</button>
                        </div>


                    </div>
                </div>
            </div>

        </div>

    </div>

    <div class=\"col-lg-12\">
        <div class=\"card\">
            <div class=\"header text-center\">
                <h2>Résultat de la recherche</h2>
            </div>
            <div class=\"body\">
            <div>
                <button class=\"btn btn-primary\" id=\"export\">Export Excel</button>
            </div>
                <div class=\"table-responsive\">
                    <table class=\"table\" id=\"tbjeune\">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>NOM</th>
                            <th>PRENOMS</th>

                            <th>GROUPE</th>
                            <th>TELEPHONE</th>
";
        // line 97
        echo "                        </tr>
                        </thead>
                        <tbody>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>




    <div class=\"modal fade bd-example-modal-lg\" data-backdrop=\"static\" data-keyboard=\"false\" tabindex=\"-1\">
        <div class=\"modal-dialog modal-sm\">
            <div class=\"modal-content\" style=\"width: 48px\">
                <span class=\"fa fa-spinner fa-spin fa-3x\"></span>
            </div>
        </div>
    </div>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 120
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 121
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/jquery-datatable/jquery.dataTables.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 122
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/sweetalert/sweetalert.min.js"), "html", null, true);
        echo " \"></script>


    <script src=\"";
        // line 125
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/bundles/datatablescripts.bundle.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 126
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/jquery-datatable/buttons/dataTables.buttons.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 127
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/jquery-datatable/buttons/buttons.bootstrap4.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 128
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/jquery-datatable/buttons/buttons.colVis.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 129
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/jquery-datatable/buttons/buttons.html5.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 130
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/jquery-datatable/buttons/buttons.print.min.js"), "html", null, true);
        echo "\"></script>

    <script>
        \$(document).ready(function(){
            debugger
            var groupe=\"\";
            var branche=\"\";
            var table = \$(\"#tbjeune\").DataTable({
                language: {
                    processing: \"Traitement en cours...\",
                    search: \"Rechercher&nbsp;:\",
                    lengthMenu: \"Afficher _MENU_ &eacute;l&eacute;ments\",
                    info: \"Affichage de l'&eacute;lement _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments\",
                    infoEmpty: \"Affichage de l'&eacute;lement 0 &agrave; 0 sur 0 &eacute;l&eacute;ments\",
                    infoFiltered: \"(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)\",
                    infoPostFix: \"\",
                    loadingRecords: \"Chargement en cours...\",
                    zeroRecords: \"Aucun &eacute;l&eacute;ment &agrave; afficher\",
                    emptyTable: \"Aucune donnée disponible dans le tableau\",
                    paginate: {
                        first: \"Premier\",
                        previous: \"Pr&eacute;c&eacute;dent\",
                        next: \"Suivant\",
                        last: \"Dernier\"
                    }
                },
                columns: [
                    { \"data\": \"ID\" },
                    { \"data\": \"NOM\" },
                    { \"data\": \"PRENOMS\" },
                  //  { \"data\": \"DATE DE NAISSANCE\" },
                    { \"data\": \"GROUPE\" },
                    { \"data\": \"TELEPHONE\" },
                    // { \"data\": \"ACTION\" }
                ],
                columnDefs: [
                    {
                        targets: 0,
                        visible: false
                    }],
                data: [],
                rowCallback: function (row, data) { },
                filter: true,
                info: true,
                ordering: false,
                processing: false,
                retrieve: true
            });
            debugger
            function loading()
            {
                \$('.modal').modal('show');

            }
            function loadingClose()
            {
                \$('.modal').modal('hide');

            }
            \$.ajax({
                type:\"GET\",
                url:\"";
        // line 191
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("GetListBranche");
        echo "\",
                success:function(resp){
                    debugger
                    \$(\"#brache\").empty();
                    var defaultline = \"<option selected='selected' value='-1'>---selectionner branche---</option>\";
                    \$(\"#branche\").append(defaultline);
                    var liste = JSON.parse(resp);
                    \$.each(liste,function(i,n){
                        debugger
                        var line = \"<option value=\"+n.id+\">\"+n.Libelle+\"</option>\";
                        \$(\"#branche\").append(line);

                    });
                }
            });
            \$.ajax({
                type:\"GET\",
                url:\"";
        // line 208
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("GetListGroupe");
        echo "\",
                success:function(resp){
                    debugger
                    \$(\"#groupe\").empty();
                    var defaultline = \"<option selected=selected value='-1'>---selectionner groupe---</option>\";
                    \$(\"#groupe\").append(defaultline);
                    var liste = JSON.parse(resp);
                    \$.each(liste,function(i,n){
                        debugger
                        var line = \"<option value=\"+n.id+\">\"+n.Nom+\"</option>\";
                        \$(\"#groupe\").append(line);

                    });
                }
            });





            \$(\"#valider\").click(function (){
                debugger
                groupe = \"\";
                branche=\"\";
                loading();
                 branche = \$(\"#branche\").val();
                 groupe = \$(\"#groupe\").val();
                if ( branche=='-1' || groupe=='-1')
                {

                    swal({
                        type:\"warning\",
                        title: \"\",
                        text:\"Veuillez faire un choix correct\"
                    },function () {
                        loadingClose();
                    });
                }
                else
                {


                    \$.ajax({
                        type:\"GET\",
                        url:\"";
        // line 252
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("RechercheJeuneByCriteria");
        echo "\",
                        data:{ branche : branche, groupe : groupe},
                        success:function(res){
                            debugger
                            loadingClose();
                            table.clear().draw();
                            if(res==\"\")
                            {
                                swal({
                                    title:\"\",
                                    text:\"Auncun enregistrement trouvé\"
                                });
                            }
                            else
                            {

                                var liste = JSON.parse(res);
                                \$.each(liste,function(i,n){
                                    table.rows.add([{
                                        \"ID\":n.id,
                                        \"NOM\":n.Nom,
                                        \"PRENOMS\":n.Prenoms ,
                                        \"GROUPE\": n.nomgroupe,
                                        \"TELEPHONE\" :n.Telephone


                                    }]).draw();
                                });
                                loadingClose();
                            }

                        },
                        error: function(){
                            loadingClose();
                        }
                    });
                }


            });

            \$(\"#export\").click(function(){
                debugger
                window.location.href = \"/ExportJeuneDistrict/\"+groupe+\"/\"+branche;
            });

        });
    </script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "district/ListeJeune.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  418 => 252,  371 => 208,  351 => 191,  287 => 130,  283 => 129,  279 => 128,  275 => 127,  271 => 126,  267 => 125,  261 => 122,  256 => 121,  246 => 120,  214 => 97,  145 => 29,  135 => 28,  109 => 12,  105 => 11,  101 => 10,  95 => 8,  90 => 6,  80 => 5,  61 => 3,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base_district.html.twig' %}

{% block titre %}LISTE DES JEUNES {% endblock %}

{% block stylesheets %}
    <link rel=\"stylesheet\" href=\"{{ asset('assets/vendor/jquery-datatable/dataTables.bootstrap4.min.css') }}\"/>
    {#    <link rel=\"stylesheet\" href=\"{{ asset('assets/vendor/font-awesome/css/font-awesome.min.css') }}\"/>#}
    <link rel=\"stylesheet\" href=\"{{ asset(\"assets/vendor/sweetalert/sweetalert.css\") }}\"/>

    <link rel=\"stylesheet\" href=\"{{ asset(\"assets/vendor/jquery-datatable/dataTables.bootstrap4.min.css\") }}\">
    <link rel=\"stylesheet\" href=\"{{ asset(\"assets/vendor/jquery-datatable/fixedeader/dataTables.fixedcolumns.bootstrap4.min.css\") }}\">
    <link rel=\"stylesheet\" href=\"{{ asset(\"assets/vendor/jquery-datatable/fixedeader/dataTables.fixedheader.bootstrap4.min.css\") }}\">
    <style>
        .bd-example-modal-lg .modal-dialog{
            display: table;
            position: relative;
            margin: 0 auto;
            top: calc(50% - 24px);
        }

        .bd-example-modal-lg .modal-dialog .modal-content{
            background-color: transparent;
            border: none;
        }

    </style>
{% endblock %}
{% block body %}
    <style>
        .example-wrapper { margin: 1em auto; max-width: 800px; width: 95%; font: 18px/1.5 sans-serif; }
        .example-wrapper code { background: #F5F5F5; padding: 2px 6px; }
    </style>
    <div class=\"container-fluid\">

        <div class=\"row clearfix\">
            <div class=\"col-md-12\">
                <div class=\"card\">
                    <div class=\"header\">
                        <h2 class=\"text-center\">Recherche des jeunes par critère</h2>
                    </div>
                    <div class=\"body\">
                        <div class=\"row\">
                            <div class=\"col-md-6\">
                                <div class=\"form-group\">
                                    <label>Groupe</label>
                                    <select id=\"groupe\" class=\"form-control\"></select>
                                </div>
                            </div>

                            <div class=\"col-md-6\">

                                <div class=\"form-group\">
                                    <label>Branche</label>
                                    <select id=\"branche\" class=\"form-control\"></select>
                                </div>

                            </div>

                        </div>



                        <div class=\"text-center\">
                            <button type=\"submit\" class=\"btn btn-success\" id=\"valider\">Rechercher</button>
                            <button type=\"submit\" class=\"btn btn-danger\">Annuler</button>
                        </div>


                    </div>
                </div>
            </div>

        </div>

    </div>

    <div class=\"col-lg-12\">
        <div class=\"card\">
            <div class=\"header text-center\">
                <h2>Résultat de la recherche</h2>
            </div>
            <div class=\"body\">
            <div>
                <button class=\"btn btn-primary\" id=\"export\">Export Excel</button>
            </div>
                <div class=\"table-responsive\">
                    <table class=\"table\" id=\"tbjeune\">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>NOM</th>
                            <th>PRENOMS</th>

                            <th>GROUPE</th>
                            <th>TELEPHONE</th>
{#                            <th>ACTION</th>#}
                        </tr>
                        </thead>
                        <tbody>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>




    <div class=\"modal fade bd-example-modal-lg\" data-backdrop=\"static\" data-keyboard=\"false\" tabindex=\"-1\">
        <div class=\"modal-dialog modal-sm\">
            <div class=\"modal-content\" style=\"width: 48px\">
                <span class=\"fa fa-spinner fa-spin fa-3x\"></span>
            </div>
        </div>
    </div>

{% endblock %}
{% block javascripts %}
    <script src=\"{{ asset('assets/vendor/jquery-datatable/jquery.dataTables.min.js') }}\"></script>
    <script src=\"{{ asset(\"assets/vendor/sweetalert/sweetalert.min.js\")}} \"></script>


    <script src=\"{{ asset(\"assets/bundles/datatablescripts.bundle.js\") }}\"></script>
    <script src=\"{{ asset(\"assets/vendor/jquery-datatable/buttons/dataTables.buttons.min.js\") }}\"></script>
    <script src=\"{{ asset(\"assets/vendor/jquery-datatable/buttons/buttons.bootstrap4.min.js\") }}\"></script>
    <script src=\"{{ asset(\"assets/vendor/jquery-datatable/buttons/buttons.colVis.min.js\") }}\"></script>
    <script src=\"{{ asset(\"assets/vendor/jquery-datatable/buttons/buttons.html5.min.js\") }}\"></script>
    <script src=\"{{ asset(\"assets/vendor/jquery-datatable/buttons/buttons.print.min.js\") }}\"></script>

    <script>
        \$(document).ready(function(){
            debugger
            var groupe=\"\";
            var branche=\"\";
            var table = \$(\"#tbjeune\").DataTable({
                language: {
                    processing: \"Traitement en cours...\",
                    search: \"Rechercher&nbsp;:\",
                    lengthMenu: \"Afficher _MENU_ &eacute;l&eacute;ments\",
                    info: \"Affichage de l'&eacute;lement _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments\",
                    infoEmpty: \"Affichage de l'&eacute;lement 0 &agrave; 0 sur 0 &eacute;l&eacute;ments\",
                    infoFiltered: \"(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)\",
                    infoPostFix: \"\",
                    loadingRecords: \"Chargement en cours...\",
                    zeroRecords: \"Aucun &eacute;l&eacute;ment &agrave; afficher\",
                    emptyTable: \"Aucune donnée disponible dans le tableau\",
                    paginate: {
                        first: \"Premier\",
                        previous: \"Pr&eacute;c&eacute;dent\",
                        next: \"Suivant\",
                        last: \"Dernier\"
                    }
                },
                columns: [
                    { \"data\": \"ID\" },
                    { \"data\": \"NOM\" },
                    { \"data\": \"PRENOMS\" },
                  //  { \"data\": \"DATE DE NAISSANCE\" },
                    { \"data\": \"GROUPE\" },
                    { \"data\": \"TELEPHONE\" },
                    // { \"data\": \"ACTION\" }
                ],
                columnDefs: [
                    {
                        targets: 0,
                        visible: false
                    }],
                data: [],
                rowCallback: function (row, data) { },
                filter: true,
                info: true,
                ordering: false,
                processing: false,
                retrieve: true
            });
            debugger
            function loading()
            {
                \$('.modal').modal('show');

            }
            function loadingClose()
            {
                \$('.modal').modal('hide');

            }
            \$.ajax({
                type:\"GET\",
                url:\"{{ path(\"GetListBranche\")}}\",
                success:function(resp){
                    debugger
                    \$(\"#brache\").empty();
                    var defaultline = \"<option selected='selected' value='-1'>---selectionner branche---</option>\";
                    \$(\"#branche\").append(defaultline);
                    var liste = JSON.parse(resp);
                    \$.each(liste,function(i,n){
                        debugger
                        var line = \"<option value=\"+n.id+\">\"+n.Libelle+\"</option>\";
                        \$(\"#branche\").append(line);

                    });
                }
            });
            \$.ajax({
                type:\"GET\",
                url:\"{{ path(\"GetListGroupe\")}}\",
                success:function(resp){
                    debugger
                    \$(\"#groupe\").empty();
                    var defaultline = \"<option selected=selected value='-1'>---selectionner groupe---</option>\";
                    \$(\"#groupe\").append(defaultline);
                    var liste = JSON.parse(resp);
                    \$.each(liste,function(i,n){
                        debugger
                        var line = \"<option value=\"+n.id+\">\"+n.Nom+\"</option>\";
                        \$(\"#groupe\").append(line);

                    });
                }
            });





            \$(\"#valider\").click(function (){
                debugger
                groupe = \"\";
                branche=\"\";
                loading();
                 branche = \$(\"#branche\").val();
                 groupe = \$(\"#groupe\").val();
                if ( branche=='-1' || groupe=='-1')
                {

                    swal({
                        type:\"warning\",
                        title: \"\",
                        text:\"Veuillez faire un choix correct\"
                    },function () {
                        loadingClose();
                    });
                }
                else
                {


                    \$.ajax({
                        type:\"GET\",
                        url:\"{{ path(\"RechercheJeuneByCriteria\") }}\",
                        data:{ branche : branche, groupe : groupe},
                        success:function(res){
                            debugger
                            loadingClose();
                            table.clear().draw();
                            if(res==\"\")
                            {
                                swal({
                                    title:\"\",
                                    text:\"Auncun enregistrement trouvé\"
                                });
                            }
                            else
                            {

                                var liste = JSON.parse(res);
                                \$.each(liste,function(i,n){
                                    table.rows.add([{
                                        \"ID\":n.id,
                                        \"NOM\":n.Nom,
                                        \"PRENOMS\":n.Prenoms ,
                                        \"GROUPE\": n.nomgroupe,
                                        \"TELEPHONE\" :n.Telephone


                                    }]).draw();
                                });
                                loadingClose();
                            }

                        },
                        error: function(){
                            loadingClose();
                        }
                    });
                }


            });

            \$(\"#export\").click(function(){
                debugger
                window.location.href = \"/ExportJeuneDistrict/\"+groupe+\"/\"+branche;
            });

        });
    </script>
{% endblock %}", "district/ListeJeune.html.twig", "D:\\CODES SOURCES\\SYMFONY\\GestiScoutWeb\\templates\\district\\ListeJeune.html.twig");
    }
}

<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* configuration/Groupe.html.twig */
class __TwigTemplate_16594959f892c71e91f20a624962bafc3f0396cfe982b7894fcbe53f9bade73c extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'titre' => [$this, 'block_titre'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base_district.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "configuration/Groupe.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "configuration/Groupe.html.twig"));

        $this->parent = $this->loadTemplate("base_district.html.twig", "configuration/Groupe.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_titre($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "titre"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "titre"));

        echo "ANNEE PASTORALE ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 6
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/sweetalert/sweetalert.css"), "html", null, true);
        echo "\"/>
    <link rel=\"stylesheet\" href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/jquery-datatable/dataTables.bootstrap4.min.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/jquery-datatable/fixedeader/dataTables.fixedcolumns.bootstrap4.min.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/jquery-datatable/fixedeader/dataTables.fixedheader.bootstrap4.min.css"), "html", null, true);
        echo "\">
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 11
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "<style>
    .example-wrapper { margin: 1em auto; max-width: 800px; width: 95%; font: 18px/1.5 sans-serif; }
    .example-wrapper code { background: #F5F5F5; padding: 2px 6px; }
</style>
    <div class=\"container-fluid\">
           
        <div class=\"row clearfix\">
            <div class=\"col-md-12\">
                <div class=\"card\">
                    <div class=\"header\">
                        <h2 class=\"text-center\">CONFIGURER LES GROUPES</h2>
                    </div>
                    <div class=\"body\">
                    <input type=\"hidden\" id=\"idgroupe\" />
                        <div class=\"row\">
                      <div class=\"col-md-6\">
                            <div class=\"form-group\">
                                <label>Nom</label>
                                <input type=\"text\" class=\"form-control\" required id=\"nom\" placeholder=\"Nom du groupe\">
                            </div>
                      </div>

                        <div class=\"col-md-6\">

                            <div class=\"form-group\">
                                <label>NickName</label>
                                <input type=\"text\" class=\"form-control\" required id=\"nickname\" placeholder=\"nom amérindien du groupe\">
                            </div>

                        </div>

                    </div>
                        <div class=\"row\">
                            <div class=\"col-md-6\">
                                <div class=\"form-group\">
                                    <label>Region</label>
                                    <input type=\"text\" class=\"form-control\" required id=\"region\" placeholder=\"région\">
                                </div>
                            </div>

                            <div class=\"col-md-6\">

                                <div class=\"form-group\">
                                    <label>Paroisse</label>
                                    <input type=\"text\" class=\"form-control\" required id=\"paroisse\" placeholder=\"paroisse\">
                                </div>

                            </div>

                        </div>

                        <div class=\"row\">
                            <div class=\"col-md-6\">
                                <div class=\"form-group\">
                                    <label>Téléphone1</label>
                                    <input type=\"tel\" class=\"form-control\" required id=\"phone1\" placeholder=\"numero de téléphone\">
                                </div>
                            </div>

                            <div class=\"col-md-6\">

                                <div class=\"form-group\">
                                    <label>Téléphone2</label>
                                    <input type=\"tel\" class=\"form-control\" required id=\"phone2\" placeholder=\"numéro de téléphone\">
                                </div>

                            </div>

                        </div>



                        <div class=\"row\">
                            <div class=\"col-md-6\">
                                <div class=\"form-group\">
                                    <label>email</label>
                                    <input type=\"email\" class=\"form-control\" required id=\"email\" placeholder=\"email du groupe\">
                                </div>
                            </div>



                        </div>



                        <div class=\"row\">
                            <div class=\"col-md-6\">
                                <div class=\"form-group\">
                                    <label>Logo</label>
                                    <input type=\"file\" class=\"form-control\" required id=\"logo\" placeholder=\"choisir le logo\">
                                </div>
                            </div>

                            <div class=\"col-md-6\">

                                <div class=\"form-group\">
                                  <img src=\"\" id=\"image\" width=\"150\" height=\"150\">
                                </div>

                            </div>

                        </div>


                        <div class=\"text-center\"> 
                            <button type=\"submit\" class=\"btn btn-success\" id=\"valider\">Valider</button>
                            <button type=\"submit\" class=\"btn btn-primary\" id=\"modifier\">Modifier</button>
                            <button type=\"submit\" class=\"btn btn-danger\" id=\"btnannuler\">Annuler</button>
                        </div>
                            
                        
                    </div>
                </div>
            </div>
          
        </div>
        
    </div>
    
<div class=\"col-lg-12\">
    <div class=\"card\">
        <div class=\"header\">
            <h2>Liste des jeunes</h2>
        </div>
        <div class=\"body\">
            <div class=\"table-responsive\">
                <table class=\"table\" id=\"tbFonction\">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>NOM</th>
                            <th>NICKNAME</th>
                            <th>REGION</th>
                            <th>PAROISSE</th>
                            <th>TELEPHONE</th>
                            <th>ACTION</th>
                        </tr>
                    </thead>
                   <tbody>

                   </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 160
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 161
        echo "<script src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/jquery-datatable/jquery.dataTables.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 162
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/vendor/sweetalert/sweetalert.min.js"), "html", null, true);
        echo " \"></script>
<script>
    \$(document).ready(function(){
        debugger
        \$(\"#modifier\").hide();
      var table = \$(\"#tbFonction\").DataTable({
          language: {
              processing: \"Traitement en cours...\",
              search: \"Rechercher&nbsp;:\",
              lengthMenu: \"Afficher _MENU_ &eacute;l&eacute;ments\",
              info: \"Affichage de l'&eacute;lement _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments\",
              infoEmpty: \"Affichage de l'&eacute;lement 0 &agrave; 0 sur 0 &eacute;l&eacute;ments\",
              infoFiltered: \"(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)\",
              infoPostFix: \"\",
              loadingRecords: \"Chargement en cours...\",
              zeroRecords: \"Aucun &eacute;l&eacute;ment &agrave; afficher\",
              emptyTable: \"Aucune donnée disponible dans le tableau\",
              paginate: {
                  first: \"Premier\",
                  previous: \"Pr&eacute;c&eacute;dent\",
                  next: \"Suivant\",
                  last: \"Dernier\"
              }
          },
          columns: [
              { \"data\": \"ID\" },
              { \"data\": \"NOM\" },
              { \"data\": \"NICKNAME\" },
              { \"data\": \"REGION\" },
              { \"data\": \"PAROISSE\" },
              { \"data\": \"TELEPHONE\" },
              { \"data\": \"ACTION\" }
          ],
          // columnDefs: [
          //     {
          //         targets: 0,
          //         visible: false
          //     }],
          data: [],
          rowCallback: function (row, data) { },
          filter: true,
          info: true,
          ordering: false,
          processing: false,
          retrieve: true
      });
        debugger
         loadData();

        function loadData(){
            \$.ajax({
                type:\"GET\",
                url:\"";
        // line 214
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("GetListGroupe");
        echo "\",
                success:function(resp){
                    debugger
                    table.clear().draw();
                    var liste = JSON.parse(resp);
                    \$.each(liste,function(i,n){

                        debugger
                        //alert(n.Nom);
                        table.rows.add([{
                            \"ID\":n.id,
                            \"NOM\":n.Nom,
                            \"NICKNAME\":n.NickName ,
                            \"REGION\":n.Region,
                            \"PAROISSE\":n.Paroisse,
                            \"TELEPHONE\":n.Phone1,
                            \"ACTION\" :\"<a id='btndelete'><span><i class='fa fa-trash fa-2x'></i></span></a><a id='btnUpdate'><span><i class='fa fa-pencil fa-2x'></i></span></a><a id='btnconsult'><span><i class='fa fa-eye fa-2x'></i></span></a>\"

                        }]).draw();
                    });
                }
            });
        }

\$(\"#logo\").change(function(){
    debugger
    readURL(this);
});

    function Annuler(){
        EnableInput();


                \$(\"#nom\").val('');
                \$(\"#nickname\").val('');
                \$(\"#region\").val('');
                \$(\"#paroisse\").val('');
                \$(\"#phone1\").val('');
                \$(\"#phone2\").val('');
                \$(\"#email\").val('');
               \$(\"#logo\").val();
                \$(\"#image\").attr('src','');
                \$(\"#valider\").show();
                \$(\"#modifier\").hide();



    }
    \$(\"#btnannuler\").click(function(){
            Annuler();  
    })

        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function(e) {
                    \$('#image').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]); // convert to base64 string
            }
        }


        \$(\"#valider\").click(function (){
            debugger
            var filename = \$('input[type=file]').val().split('\\\\').pop();
            var formdata = new FormData();
           // formdata.append('img',filename);
            formdata.append('test','dfdf');
           Groupe={
               nom : \$(\"#nom\").val(),
               nickname : \$(\"#nickname\").val(),
               region : \$(\"#region\").val(),
               paroisse : \$(\"#paroisse\").val(),
               phone1: \$(\"#phone1\").val(),
               phone2: \$(\"#phone2\").val(),
               mail : \$(\"#email\").val()
               //logo : formdata
           };

           if(Groupe.nom=='' || Groupe.nickname=='' || Groupe.region =='' || Groupe.paroisse=='' || Groupe.phone1==''){
               swal({
                   type:\"warning\",
                   title:\"GROUPE\",
                   text:\"Veuillez remplir les champs obligatoire svp!\"
               });
           }else{

               \$.ajax({
                   type: \"POST\",
                   url:\"";
        // line 306
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AddGroupe");
        echo "\",
                   dataType:\"json\",
                   data: {\"value\": Groupe},
                   success:function(res){
                       debugger
                       if (res===1){
                           swal({
                               title:\"GROUPE\",
                               text:\"Enregistrement effectué avec succès\",
                               type:\"success\"

                           },function (){
                               debugger
                           });
                       }else {
                           swal({
                               type:\"error\",
                               title:\"GROUPE\",
                               text:\"Problème pendant l'opération\"
                           });
                       }

                   },
                   error:function(res){
                       debugger
                   }

               });
            }
        });

        function DisableInput(){
                \$(\"#nom\").attr('disabled','true');
                \$(\"#nickname\").attr('disabled','true');
                \$(\"#region\").attr('disabled','true');
                \$(\"#paroisse\").attr('disabled','true');
                \$(\"#phone1\").attr('disabled','true');
                \$(\"#phone2\").attr('disabled','true');
                \$(\"#email\").attr('disabled','true');
                \$(\"#valider\").attr('disabled','true');
        }


            function EnableInput(){
                \$(\"#nom\").removeAttr('disabled');
                \$(\"#nickname\").removeAttr('disabled');
                \$(\"#region\").removeAttr('disabled');
                \$(\"#paroisse\").removeAttr('disabled');
                \$(\"#phone1\").removeAttr('disabled');
                \$(\"#phone2\").removeAttr('disabled');
                \$(\"#email\").removeAttr('disabled');
                \$(\"#valider\").removeAttr('disabled');
        }

        \$(\"#tbFonction tbody\").on('click','tr > td > #btnconsult',function(){
               debugger
               DisableInput();
            var row = table.row( \$(this).parents('tr') ).data();
            var ID = row.ID;
            \$.get(\"";
        // line 365
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("GetGroupeUnique");
        echo "\",{value:ID}, function(res){
                debugger
                if (res.ok) {
                    var value = JSON.parse(res.data);
                    \$(\"#nom\").val(value.Nom);
                    \$(\"#nickname\").val(value.NickName);
                    \$(\"#region\").val(value.Region);
                    \$(\"#paroisse\").val(value.Paroisse);
                    \$(\"#phone1\").val(value.Phone1);
                    \$(\"#phone2\").val(value.Phone2);
                    \$(\"#email\").val(value.Email);







                }
                else{
                    // swal({
                    //     type:\"error\",
                    //     title:\"Grupe\",
                    //     text:res.data;
                    // });
                }
            })
            

        });


           \$(\"#tbFonction tbody\").on('click','tr > td > #btnUpdate',function(){
               debugger
               EnableInput();
               \$(\"#modifier\").show();
               \$(\"#valider\").hide();
            var row = table.row( \$(this).parents('tr') ).data();
            var ID = row.ID;
            \$.get(\"";
        // line 404
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("GetGroupeUnique");
        echo "\",{value:ID}, function(res){
                debugger
                if (res.ok) {
                    var value = JSON.parse(res.data);
                    \$(\"#nom\").val(value.Nom);
                    \$(\"#nickname\").val(value.NickName);
                    \$(\"#region\").val(value.Region);
                    \$(\"#paroisse\").val(value.Paroisse);
                    \$(\"#phone1\").val(value.Phone1);
                    \$(\"#phone2\").val(value.Phone2);
                    \$(\"#email\").val(value.Email);
                    \$(\"#idgroupe\").val(value.id);







                }
                else{
                    // swal({
                    //     type:\"error\",
                    //     title:\"Grupe\",
                    //     text:res.data;
                    // });
                }
            })
            

        });


        \$(\"#modifier\").click(function(){
              var  Groupe={
                id:\$(\"#idgroupe\").val(),
               nom : \$(\"#nom\").val(),
               nickname : \$(\"#nickname\").val(),
               region : \$(\"#region\").val(),
               paroisse : \$(\"#paroisse\").val(),
               phone1: \$(\"#phone1\").val(),
               phone2: \$(\"#phone2\").val(),
               email : \$(\"#email\").val()
               //logo : formdata
           };

        \$.post(\"";
        // line 450
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("UpdateGroupe");
        echo "\",{value:Groupe}, function(res){
            debugger
            if(res.ok){
                    swal({
                        type:\"success\",
                        title:\"Groupe\",
                        text: res.message
                    },function(){
                        loadData();
                        Annuler();
                    })
            }
            else{

            }
        });


        });


    });
</script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "configuration/Groupe.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  600 => 450,  551 => 404,  509 => 365,  447 => 306,  352 => 214,  297 => 162,  292 => 161,  282 => 160,  125 => 12,  115 => 11,  103 => 9,  99 => 8,  95 => 7,  90 => 6,  80 => 5,  61 => 3,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base_district.html.twig' %}

{% block titre %}ANNEE PASTORALE {% endblock %}

{% block stylesheets %}
    <link rel=\"stylesheet\" href=\"{{ asset(\"assets/vendor/sweetalert/sweetalert.css\") }}\"/>
    <link rel=\"stylesheet\" href=\"{{ asset(\"assets/vendor/jquery-datatable/dataTables.bootstrap4.min.css\") }}\">
    <link rel=\"stylesheet\" href=\"{{ asset(\"assets/vendor/jquery-datatable/fixedeader/dataTables.fixedcolumns.bootstrap4.min.css\") }}\">
    <link rel=\"stylesheet\" href=\"{{ asset(\"assets/vendor/jquery-datatable/fixedeader/dataTables.fixedheader.bootstrap4.min.css\") }}\">
{% endblock %}
{% block body %}
<style>
    .example-wrapper { margin: 1em auto; max-width: 800px; width: 95%; font: 18px/1.5 sans-serif; }
    .example-wrapper code { background: #F5F5F5; padding: 2px 6px; }
</style>
    <div class=\"container-fluid\">
           
        <div class=\"row clearfix\">
            <div class=\"col-md-12\">
                <div class=\"card\">
                    <div class=\"header\">
                        <h2 class=\"text-center\">CONFIGURER LES GROUPES</h2>
                    </div>
                    <div class=\"body\">
                    <input type=\"hidden\" id=\"idgroupe\" />
                        <div class=\"row\">
                      <div class=\"col-md-6\">
                            <div class=\"form-group\">
                                <label>Nom</label>
                                <input type=\"text\" class=\"form-control\" required id=\"nom\" placeholder=\"Nom du groupe\">
                            </div>
                      </div>

                        <div class=\"col-md-6\">

                            <div class=\"form-group\">
                                <label>NickName</label>
                                <input type=\"text\" class=\"form-control\" required id=\"nickname\" placeholder=\"nom amérindien du groupe\">
                            </div>

                        </div>

                    </div>
                        <div class=\"row\">
                            <div class=\"col-md-6\">
                                <div class=\"form-group\">
                                    <label>Region</label>
                                    <input type=\"text\" class=\"form-control\" required id=\"region\" placeholder=\"région\">
                                </div>
                            </div>

                            <div class=\"col-md-6\">

                                <div class=\"form-group\">
                                    <label>Paroisse</label>
                                    <input type=\"text\" class=\"form-control\" required id=\"paroisse\" placeholder=\"paroisse\">
                                </div>

                            </div>

                        </div>

                        <div class=\"row\">
                            <div class=\"col-md-6\">
                                <div class=\"form-group\">
                                    <label>Téléphone1</label>
                                    <input type=\"tel\" class=\"form-control\" required id=\"phone1\" placeholder=\"numero de téléphone\">
                                </div>
                            </div>

                            <div class=\"col-md-6\">

                                <div class=\"form-group\">
                                    <label>Téléphone2</label>
                                    <input type=\"tel\" class=\"form-control\" required id=\"phone2\" placeholder=\"numéro de téléphone\">
                                </div>

                            </div>

                        </div>



                        <div class=\"row\">
                            <div class=\"col-md-6\">
                                <div class=\"form-group\">
                                    <label>email</label>
                                    <input type=\"email\" class=\"form-control\" required id=\"email\" placeholder=\"email du groupe\">
                                </div>
                            </div>



                        </div>



                        <div class=\"row\">
                            <div class=\"col-md-6\">
                                <div class=\"form-group\">
                                    <label>Logo</label>
                                    <input type=\"file\" class=\"form-control\" required id=\"logo\" placeholder=\"choisir le logo\">
                                </div>
                            </div>

                            <div class=\"col-md-6\">

                                <div class=\"form-group\">
                                  <img src=\"\" id=\"image\" width=\"150\" height=\"150\">
                                </div>

                            </div>

                        </div>


                        <div class=\"text-center\"> 
                            <button type=\"submit\" class=\"btn btn-success\" id=\"valider\">Valider</button>
                            <button type=\"submit\" class=\"btn btn-primary\" id=\"modifier\">Modifier</button>
                            <button type=\"submit\" class=\"btn btn-danger\" id=\"btnannuler\">Annuler</button>
                        </div>
                            
                        
                    </div>
                </div>
            </div>
          
        </div>
        
    </div>
    
<div class=\"col-lg-12\">
    <div class=\"card\">
        <div class=\"header\">
            <h2>Liste des jeunes</h2>
        </div>
        <div class=\"body\">
            <div class=\"table-responsive\">
                <table class=\"table\" id=\"tbFonction\">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>NOM</th>
                            <th>NICKNAME</th>
                            <th>REGION</th>
                            <th>PAROISSE</th>
                            <th>TELEPHONE</th>
                            <th>ACTION</th>
                        </tr>
                    </thead>
                   <tbody>

                   </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
{% endblock %}
{% block javascripts %}
<script src=\"{{ asset('assets/vendor/jquery-datatable/jquery.dataTables.min.js') }}\"></script>
    <script src=\"{{ asset(\"assets/vendor/sweetalert/sweetalert.min.js\")}} \"></script>
<script>
    \$(document).ready(function(){
        debugger
        \$(\"#modifier\").hide();
      var table = \$(\"#tbFonction\").DataTable({
          language: {
              processing: \"Traitement en cours...\",
              search: \"Rechercher&nbsp;:\",
              lengthMenu: \"Afficher _MENU_ &eacute;l&eacute;ments\",
              info: \"Affichage de l'&eacute;lement _START_ &agrave; _END_ sur _TOTAL_ &eacute;l&eacute;ments\",
              infoEmpty: \"Affichage de l'&eacute;lement 0 &agrave; 0 sur 0 &eacute;l&eacute;ments\",
              infoFiltered: \"(filtr&eacute; de _MAX_ &eacute;l&eacute;ments au total)\",
              infoPostFix: \"\",
              loadingRecords: \"Chargement en cours...\",
              zeroRecords: \"Aucun &eacute;l&eacute;ment &agrave; afficher\",
              emptyTable: \"Aucune donnée disponible dans le tableau\",
              paginate: {
                  first: \"Premier\",
                  previous: \"Pr&eacute;c&eacute;dent\",
                  next: \"Suivant\",
                  last: \"Dernier\"
              }
          },
          columns: [
              { \"data\": \"ID\" },
              { \"data\": \"NOM\" },
              { \"data\": \"NICKNAME\" },
              { \"data\": \"REGION\" },
              { \"data\": \"PAROISSE\" },
              { \"data\": \"TELEPHONE\" },
              { \"data\": \"ACTION\" }
          ],
          // columnDefs: [
          //     {
          //         targets: 0,
          //         visible: false
          //     }],
          data: [],
          rowCallback: function (row, data) { },
          filter: true,
          info: true,
          ordering: false,
          processing: false,
          retrieve: true
      });
        debugger
         loadData();

        function loadData(){
            \$.ajax({
                type:\"GET\",
                url:\"{{ path(\"GetListGroupe\")}}\",
                success:function(resp){
                    debugger
                    table.clear().draw();
                    var liste = JSON.parse(resp);
                    \$.each(liste,function(i,n){

                        debugger
                        //alert(n.Nom);
                        table.rows.add([{
                            \"ID\":n.id,
                            \"NOM\":n.Nom,
                            \"NICKNAME\":n.NickName ,
                            \"REGION\":n.Region,
                            \"PAROISSE\":n.Paroisse,
                            \"TELEPHONE\":n.Phone1,
                            \"ACTION\" :\"<a id='btndelete'><span><i class='fa fa-trash fa-2x'></i></span></a><a id='btnUpdate'><span><i class='fa fa-pencil fa-2x'></i></span></a><a id='btnconsult'><span><i class='fa fa-eye fa-2x'></i></span></a>\"

                        }]).draw();
                    });
                }
            });
        }

\$(\"#logo\").change(function(){
    debugger
    readURL(this);
});

    function Annuler(){
        EnableInput();


                \$(\"#nom\").val('');
                \$(\"#nickname\").val('');
                \$(\"#region\").val('');
                \$(\"#paroisse\").val('');
                \$(\"#phone1\").val('');
                \$(\"#phone2\").val('');
                \$(\"#email\").val('');
               \$(\"#logo\").val();
                \$(\"#image\").attr('src','');
                \$(\"#valider\").show();
                \$(\"#modifier\").hide();



    }
    \$(\"#btnannuler\").click(function(){
            Annuler();  
    })

        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function(e) {
                    \$('#image').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]); // convert to base64 string
            }
        }


        \$(\"#valider\").click(function (){
            debugger
            var filename = \$('input[type=file]').val().split('\\\\').pop();
            var formdata = new FormData();
           // formdata.append('img',filename);
            formdata.append('test','dfdf');
           Groupe={
               nom : \$(\"#nom\").val(),
               nickname : \$(\"#nickname\").val(),
               region : \$(\"#region\").val(),
               paroisse : \$(\"#paroisse\").val(),
               phone1: \$(\"#phone1\").val(),
               phone2: \$(\"#phone2\").val(),
               mail : \$(\"#email\").val()
               //logo : formdata
           };

           if(Groupe.nom=='' || Groupe.nickname=='' || Groupe.region =='' || Groupe.paroisse=='' || Groupe.phone1==''){
               swal({
                   type:\"warning\",
                   title:\"GROUPE\",
                   text:\"Veuillez remplir les champs obligatoire svp!\"
               });
           }else{

               \$.ajax({
                   type: \"POST\",
                   url:\"{{ path(\"AddGroupe\") }}\",
                   dataType:\"json\",
                   data: {\"value\": Groupe},
                   success:function(res){
                       debugger
                       if (res===1){
                           swal({
                               title:\"GROUPE\",
                               text:\"Enregistrement effectué avec succès\",
                               type:\"success\"

                           },function (){
                               debugger
                           });
                       }else {
                           swal({
                               type:\"error\",
                               title:\"GROUPE\",
                               text:\"Problème pendant l'opération\"
                           });
                       }

                   },
                   error:function(res){
                       debugger
                   }

               });
            }
        });

        function DisableInput(){
                \$(\"#nom\").attr('disabled','true');
                \$(\"#nickname\").attr('disabled','true');
                \$(\"#region\").attr('disabled','true');
                \$(\"#paroisse\").attr('disabled','true');
                \$(\"#phone1\").attr('disabled','true');
                \$(\"#phone2\").attr('disabled','true');
                \$(\"#email\").attr('disabled','true');
                \$(\"#valider\").attr('disabled','true');
        }


            function EnableInput(){
                \$(\"#nom\").removeAttr('disabled');
                \$(\"#nickname\").removeAttr('disabled');
                \$(\"#region\").removeAttr('disabled');
                \$(\"#paroisse\").removeAttr('disabled');
                \$(\"#phone1\").removeAttr('disabled');
                \$(\"#phone2\").removeAttr('disabled');
                \$(\"#email\").removeAttr('disabled');
                \$(\"#valider\").removeAttr('disabled');
        }

        \$(\"#tbFonction tbody\").on('click','tr > td > #btnconsult',function(){
               debugger
               DisableInput();
            var row = table.row( \$(this).parents('tr') ).data();
            var ID = row.ID;
            \$.get(\"{{path(\"GetGroupeUnique\")}}\",{value:ID}, function(res){
                debugger
                if (res.ok) {
                    var value = JSON.parse(res.data);
                    \$(\"#nom\").val(value.Nom);
                    \$(\"#nickname\").val(value.NickName);
                    \$(\"#region\").val(value.Region);
                    \$(\"#paroisse\").val(value.Paroisse);
                    \$(\"#phone1\").val(value.Phone1);
                    \$(\"#phone2\").val(value.Phone2);
                    \$(\"#email\").val(value.Email);







                }
                else{
                    // swal({
                    //     type:\"error\",
                    //     title:\"Grupe\",
                    //     text:res.data;
                    // });
                }
            })
            

        });


           \$(\"#tbFonction tbody\").on('click','tr > td > #btnUpdate',function(){
               debugger
               EnableInput();
               \$(\"#modifier\").show();
               \$(\"#valider\").hide();
            var row = table.row( \$(this).parents('tr') ).data();
            var ID = row.ID;
            \$.get(\"{{path(\"GetGroupeUnique\")}}\",{value:ID}, function(res){
                debugger
                if (res.ok) {
                    var value = JSON.parse(res.data);
                    \$(\"#nom\").val(value.Nom);
                    \$(\"#nickname\").val(value.NickName);
                    \$(\"#region\").val(value.Region);
                    \$(\"#paroisse\").val(value.Paroisse);
                    \$(\"#phone1\").val(value.Phone1);
                    \$(\"#phone2\").val(value.Phone2);
                    \$(\"#email\").val(value.Email);
                    \$(\"#idgroupe\").val(value.id);







                }
                else{
                    // swal({
                    //     type:\"error\",
                    //     title:\"Grupe\",
                    //     text:res.data;
                    // });
                }
            })
            

        });


        \$(\"#modifier\").click(function(){
              var  Groupe={
                id:\$(\"#idgroupe\").val(),
               nom : \$(\"#nom\").val(),
               nickname : \$(\"#nickname\").val(),
               region : \$(\"#region\").val(),
               paroisse : \$(\"#paroisse\").val(),
               phone1: \$(\"#phone1\").val(),
               phone2: \$(\"#phone2\").val(),
               email : \$(\"#email\").val()
               //logo : formdata
           };

        \$.post(\"{{path(\"UpdateGroupe\")}}\",{value:Groupe}, function(res){
            debugger
            if(res.ok){
                    swal({
                        type:\"success\",
                        title:\"Groupe\",
                        text: res.message
                    },function(){
                        loadData();
                        Annuler();
                    })
            }
            else{

            }
        });


        });


    });
</script>
{% endblock %}", "configuration/Groupe.html.twig", "D:\\CODES SOURCES\\SYMFONY\\GestiScoutWeb\\templates\\configuration\\Groupe.html.twig");
    }
}

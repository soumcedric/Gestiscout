<?php


namespace App\Entity;


class UserConnectedInfo
{
    public  $Nom;
    public  $Prenoms;
    public  $Groupe;

}